﻿using System.Drawing;
using System.Windows.Forms;

namespace VaiDarBanhoOCao
{
    partial class GerirProdutos
    {
        private System.ComponentModel.IContainer components = null;
        private DataGridView dgvProdutos;
        private TextBox txtNome;
        private TextBox txtPreco;
        private TextBox txtQuantidade;
        private TextBox txtDescricao;
        private TextBox txtPesquisar;
        private Button btnAdicionar;
        private Button btnEditar;
        private Button btnRemover;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GerirProdutos));
            this.dgvProdutos = new System.Windows.Forms.DataGridView();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtPreco = new System.Windows.Forms.TextBox();
            this.txtQuantidade = new System.Windows.Forms.TextBox();
            this.txtDescricao = new System.Windows.Forms.TextBox();
            this.txtPesquisar = new System.Windows.Forms.TextBox();
            this.btnAdicionar = new System.Windows.Forms.Button();
            this.btnEditar = new System.Windows.Forms.Button();
            this.btnRemover = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProdutos)).BeginInit();
            this.SuspendLayout();

            // 
            // dgvProdutos
            // 
            this.dgvProdutos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProdutos.Location = new System.Drawing.Point(20, 60);
            this.dgvProdutos.Name = "dgvProdutos";
            this.dgvProdutos.ReadOnly = true;
            this.dgvProdutos.Size = new System.Drawing.Size(760, 200);
            this.dgvProdutos.TabIndex = 0;

            // 
            // txtNome
            // 
            this.txtNome.ForeColor = System.Drawing.Color.Gray;
            this.txtNome.Location = new System.Drawing.Point(20, 280);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(200, 20);
            this.txtNome.TabIndex = 1;
            this.txtNome.Text = "Nome do Produto";
            this.txtNome.Enter += new System.EventHandler(this.TxtNome_Enter);
            this.txtNome.Leave += new System.EventHandler(this.TxtNome_Leave);

            // 
            // txtPreco
            // 
            this.txtPreco.ForeColor = System.Drawing.Color.Gray;
            this.txtPreco.Location = new System.Drawing.Point(240, 280);
            this.txtPreco.Name = "txtPreco";
            this.txtPreco.Size = new System.Drawing.Size(100, 20);
            this.txtPreco.TabIndex = 2;
            this.txtPreco.Text = "Preço";
            this.txtPreco.Enter += new System.EventHandler(this.TxtPreco_Enter);
            this.txtPreco.Leave += new System.EventHandler(this.TxtPreco_Leave);

            // 
            // txtQuantidade
            // 
            this.txtQuantidade.ForeColor = System.Drawing.Color.Gray;
            this.txtQuantidade.Location = new System.Drawing.Point(360, 280);
            this.txtQuantidade.Name = "txtQuantidade";
            this.txtQuantidade.Size = new System.Drawing.Size(100, 20);
            this.txtQuantidade.TabIndex = 3;
            this.txtQuantidade.Text = "Quantidade";
            this.txtQuantidade.Enter += new System.EventHandler(this.TxtQuantidade_Enter);
            this.txtQuantidade.Leave += new System.EventHandler(this.TxtQuantidade_Leave);

            // 
            // txtDescricao
            // 
            this.txtDescricao.ForeColor = System.Drawing.Color.Gray;
            this.txtDescricao.Location = new System.Drawing.Point(20, 320);
            this.txtDescricao.Name = "txtDescricao";
            this.txtDescricao.Size = new System.Drawing.Size(440, 20);
            this.txtDescricao.TabIndex = 4;
            this.txtDescricao.Text = "Descrição";
            this.txtDescricao.Enter += new System.EventHandler(this.TxtDescricao_Enter);
            this.txtDescricao.Leave += new System.EventHandler(this.TxtDescricao_Leave);

            // 
            // txtPesquisar
            // 
            this.txtPesquisar.ForeColor = System.Drawing.Color.Gray;
            this.txtPesquisar.Location = new System.Drawing.Point(20, 20);
            this.txtPesquisar.Name = "txtPesquisar";
            this.txtPesquisar.Size = new System.Drawing.Size(400, 20);
            this.txtPesquisar.TabIndex = 8;
            this.txtPesquisar.Text = "Pesquisar por nome do produto...";
            this.txtPesquisar.Enter += new System.EventHandler(this.TxtPesquisar_Enter);
            this.txtPesquisar.Leave += new System.EventHandler(this.TxtPesquisar_Leave);
            this.txtPesquisar.TextChanged += new System.EventHandler(this.TxtPesquisar_TextChanged);

            // 
            // btnAdicionar
            // 
            this.btnAdicionar.Location = new System.Drawing.Point(480, 280);
            this.btnAdicionar.Name = "btnAdicionar";
            this.btnAdicionar.Size = new System.Drawing.Size(100, 30);
            this.btnAdicionar.TabIndex = 5;
            this.btnAdicionar.Text = "Adicionar";
            this.btnAdicionar.UseVisualStyleBackColor = true;
            this.btnAdicionar.Click += new System.EventHandler(this.btnAdicionar_Click);

            // 
            // btnEditar
            // 
            this.btnEditar.Location = new System.Drawing.Point(590, 280);
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.Size = new System.Drawing.Size(100, 30);
            this.btnEditar.TabIndex = 6;
            this.btnEditar.Text = "Editar";
            this.btnEditar.UseVisualStyleBackColor = true;
            this.btnEditar.Click += new System.EventHandler(this.btnEditar_Click);

            // 
            // btnRemover
            // 
            this.btnRemover.Location = new System.Drawing.Point(700, 280);
            this.btnRemover.Name = "btnRemover";
            this.btnRemover.Size = new System.Drawing.Size(100, 30);
            this.btnRemover.TabIndex = 7;
            this.btnRemover.Text = "Remover";
            this.btnRemover.UseVisualStyleBackColor = true;
            this.btnRemover.Click += new System.EventHandler(this.btnRemover_Click);

            // 
            // GerirProdutos
            // 
            this.ClientSize = new System.Drawing.Size(800, 400);
            this.Controls.Add(this.txtPesquisar);
            this.Controls.Add(this.dgvProdutos);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtPreco);
            this.Controls.Add(this.txtQuantidade);
            this.Controls.Add(this.txtDescricao);
            this.Controls.Add(this.btnAdicionar);
            this.Controls.Add(this.btnEditar);
            this.Controls.Add(this.btnRemover);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "GerirProdutos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gerir Produtos";
            this.Load += new System.EventHandler(this.GerirProdutos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvProdutos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}