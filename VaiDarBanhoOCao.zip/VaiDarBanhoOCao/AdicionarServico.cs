﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace VaiDarBanhoOCao
{
    public partial class AdicionarServico : Form
    {
        public int ServicoID { get; private set; }
        public string TipoServico { get; private set; }
        public DateTime DataServico { get; private set; }
        public decimal PrecoServico { get; private set; }
        public string ObservacoesServico { get; private set; }
        public int AnimalID { get; private set; }

        private ComboBox cbTipoServico;
        private DateTimePicker dtpDataServico;
        private TextBox txtPrecoServico, txtObservacoesServico;
        private Button btnSalvar;

        public AdicionarServico(int animalID)
        {
            InitializeComponent();
            this.Text = "Adicionar Serviço";
            this.Size = new Size(450, 400); // Aumentando o tamanho do formulário
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 248, 255); // Tema de cor relaxante
            AnimalID = animalID;
            InicializarControles();
            CarregarServicos();
        }

        public static class ligarBD
        {
            public static MySqlConnection GetConnection()
            {
                return new MySqlConnection("Server=localhost; Database=pap_cao; Uid=root; Pwd=;");
            }
        }

        private void InicializarControles()
        {
            AddLabel("Tipo de Serviço:", new Point(30, 30));
            cbTipoServico = AddComboBox(new Point(200, 30), new Size(200, 25)); // Ajustando a posição para alinhamento
            AddLabel("Data do Serviço:", new Point(30, 70));
            dtpDataServico = AddDateTimePicker(new Point(200, 70), new Size(200, 25)); // Ajustando a posição para alinhamento
            AddLabel("Preço do Serviço:", new Point(30, 110), new Size(150, 20)); // Ajuste da largura da label
            txtPrecoServico = AddTextBox(new Point(200, 110), new Size(200, 25)); // Ajustando a posição para alinhamento
            AddLabel("Observações:", new Point(30, 150));
            txtObservacoesServico = AddTextBox(new Point(200, 150), new Size(200, 60), true); // Ajustando a posição para alinhamento
            btnSalvar = AddButton("Salvar", new Point(150, 230), new Size(150, 40), BtnSalvar_Click); // Ajuste da posição do botão
        }

        private Label AddLabel(string text, Point location, Size? size = null)
        {
            var label = new Label
            {
                Text = text,
                Location = location,
                Size = size ?? new Size(120, 20),
                Font = new Font("Segoe UI", 11, FontStyle.Regular),
                ForeColor = Color.FromArgb(70, 130, 180)
            };
            this.Controls.Add(label);
            return label;
        }

        private ComboBox AddComboBox(Point location, Size size)
        {
            var comboBox = new ComboBox
            {
                Location = location,
                Size = size,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 10, FontStyle.Regular),
                BackColor = Color.White,
                ForeColor = Color.Black
            };
            this.Controls.Add(comboBox);
            return comboBox;
        }

        private DateTimePicker AddDateTimePicker(Point location, Size size)
        {
            var dateTimePicker = new DateTimePicker
            {
                Location = location,
                Size = size,
                Format = DateTimePickerFormat.Short
            };
            this.Controls.Add(dateTimePicker);
            return dateTimePicker;
        }

        private TextBox AddTextBox(Point location, Size size, bool multiline = false)
        {
            var textBox = new TextBox
            {
                Location = location,
                Size = size,
                Font = new Font("Segoe UI", 10, FontStyle.Regular),
                BackColor = Color.White,
                ForeColor = Color.Black,
                Multiline = multiline
            };
            this.Controls.Add(textBox);
            return textBox;
        }

        private Button AddButton(string text, Point location, Size size, EventHandler clickEvent)
        {
            var button = new Button
            {
                Text = text,
                Location = location,
                Size = size,
                BackColor = Color.FromArgb(100, 149, 237),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 12, FontStyle.Bold)
            };
            button.FlatAppearance.BorderSize = 0;
            button.Click += clickEvent;
            button.Paint += (sender, e) =>
            {
                var btn = sender as Button;
                var rect = new Rectangle(0, 0, btn.Width, btn.Height);
                var path = new System.Drawing.Drawing2D.GraphicsPath();
                int radius = 20;
                path.AddArc(rect.X, rect.Y, radius, radius, 180, 90);
                path.AddArc(rect.X + rect.Width - radius, rect.Y, radius, radius, 270, 90);
                path.AddArc(rect.X + rect.Width - radius, rect.Y + rect.Height - radius, radius, radius, 0, 90);
                path.AddArc(rect.X, rect.Y + rect.Height - radius, radius, radius, 90, 90);
                btn.Region = new Region(path);
            };
            this.Controls.Add(button);
            return button;
        }

        private void CarregarServicos()
        {
            using (var conexao = ligarBD.GetConnection())
            {
                try
                {
                    conexao.Open();
                    string query = "SELECT idServico, descricao FROM servico";
                    var cmd = new MySqlCommand(query, conexao);
                    var adapter = new MySqlDataAdapter(cmd);
                    var dt = new DataTable();
                    adapter.Fill(dt);
                    cbTipoServico.DataSource = dt;
                    cbTipoServico.DisplayMember = "descricao";
                    cbTipoServico.ValueMember = "idServico";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao carregar serviços: " + ex.Message);
                }
            }
        }

        private void BtnSalvar_Click(object sender, EventArgs e)
        {
            btnSalvar.Enabled = false; // Desabilita o botão para evitar múltiplos cliques

            if (cbTipoServico.SelectedIndex == -1 || !decimal.TryParse(txtPrecoServico.Text, out decimal preco))
            {
                MessageBox.Show(cbTipoServico.SelectedIndex == -1 ? "Por favor, selecione um serviço." : "Por favor, insira um preço válido.");
                btnSalvar.Enabled = true; // Reabilita o botão em caso de erro
                return;
            }

            ServicoID = Convert.ToInt32(cbTipoServico.SelectedValue);
            TipoServico = cbTipoServico.Text;
            DataServico = dtpDataServico.Value;
            PrecoServico = preco;
            ObservacoesServico = txtObservacoesServico.Text;

            if (ServicoDuplicado(AnimalID, ServicoID, DataServico))
            {
                MessageBox.Show("Este serviço já foi adicionado para este animal nesta data.");
                btnSalvar.Enabled = true; // Reabilita o botão em caso de erro
                return;
            }

            using (var conexao = ligarBD.GetConnection())
            {
                try
                {
                    conexao.Open();
                    string query = "INSERT INTO registoservicos (idAnimal, idServico, data, observacoes, preco) VALUES (@idAnimal, @idServico, @data, @observacoes, @preco)";
                    var cmd = new MySqlCommand(query, conexao);
                    cmd.Parameters.AddWithValue("@idAnimal", AnimalID);
                    cmd.Parameters.AddWithValue("@idServico", ServicoID);
                    cmd.Parameters.AddWithValue("@data", DataServico);
                    cmd.Parameters.AddWithValue("@observacoes", ObservacoesServico);
                    cmd.Parameters.AddWithValue("@preco", PrecoServico);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Serviço adicionado com sucesso.");
                    btnSalvar.Enabled = true; // Reabilita o botão após adicionar o serviço
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao salvar serviço: " + ex.Message);
                    btnSalvar.Enabled = true; // Reabilita o botão em caso de erro
                }
            }
        }

        private void AdicionarServico_Load(object sender, EventArgs e)
        {

        }

        private bool ServicoDuplicado(int idAnimal, int idServico, DateTime dataServico)
        {
            using (var conexao = ligarBD.GetConnection())
            {
                conexao.Open();
                string query = "SELECT COUNT(*) FROM registoservicos WHERE idAnimal = @idAnimal AND idServico = @idServico AND data = @dataServico";
                using (var cmd = new MySqlCommand(query, conexao))
                {
                    cmd.Parameters.AddWithValue("@idAnimal", idAnimal);
                    cmd.Parameters.AddWithValue("@idServico", idServico);
                    cmd.Parameters.AddWithValue("@dataServico", dataServico);
                    return Convert.ToInt32(cmd.ExecuteScalar()) > 0;
                }
            }
        }
    }
}