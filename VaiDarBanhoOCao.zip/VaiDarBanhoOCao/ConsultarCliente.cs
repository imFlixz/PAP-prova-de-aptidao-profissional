﻿using MySql.Data.MySqlClient;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace VaiDarBanhoOCao
{
    public partial class ConsultarCliente : Form
    {
        private DataGridView dgvClientes, dgvAnimais, dgvServicos;
        private Button btnAdicionarServico, btnAdicionarAnimal, btnEditarCliente, btnDarBaixaAnimal, btnVerAnimaisInativos;
        private Label lblClienteSelecionado, lblAnimalSelecionado;
        private TextBox txtPesquisar;
        private int idClienteSelecionado, idAnimalSelecionado;

        public ConsultarCliente()
        {
            InitializeComponent();
            InicializarControles();
            CarregarClientes();
        }

        public static class ligarBD
        {
            public static MySqlConnection GetConnection()
            {
                return new MySqlConnection("Server=localhost; Database=pap_cao; Uid=root; Pwd=;");
            }
        }

        private void InicializarControles()
        {
            this.Text = "Consultar Cliente";
            this.Size = new Size(1200, 780);
            this.BackColor = Color.FromArgb(240, 240, 240);

            Panel panelPrincipal = CriarPanel();
            this.Controls.Add(panelPrincipal);

            txtPesquisar = CriarTextBox(new Point(20, 20), new Size(800, 25), "Pesquisar por Nome, NIF ou Telefone...");
            txtPesquisar.Enter += TxtPesquisar_Enter;
            txtPesquisar.Leave += TxtPesquisar_Leave;
            txtPesquisar.TextChanged += TxtPesquisar_TextChanged;
            panelPrincipal.Controls.Add(txtPesquisar);

            dgvClientes = CriarDataGridView(new Point(20, 60), new Size(800, 200), new string[] { "idCliente", "Nome", "NIF", "Telefone" });
            dgvClientes.SelectionChanged += DgvClientes_SelectionChanged;
            panelPrincipal.Controls.Add(dgvClientes);

            dgvAnimais = CriarDataGridView(new Point(20, 270), new Size(800, 200), new string[] { "idAnimal", "NomeAnimal", "Raca", "Observacoes" });
            dgvAnimais.SelectionChanged += DgvAnimais_SelectionChanged;
            panelPrincipal.Controls.Add(dgvAnimais);

            dgvServicos = CriarDataGridView(new Point(20, 490), new Size(800, 150), new string[] { "DataServico", "Descricao", "Preco" });
            panelPrincipal.Controls.Add(dgvServicos);

            lblClienteSelecionado = CriarLabel("Cliente Selecionado: Nenhum", new Point(850, 20));
            panelPrincipal.Controls.Add(lblClienteSelecionado);

            lblAnimalSelecionado = CriarLabel("Animal Selecionado: Nenhum", new Point(850, 250));
            panelPrincipal.Controls.Add(lblAnimalSelecionado);

            GroupBox groupBoxCliente = new GroupBox
            {
                Text = "Ações do Cliente",
                Location = new Point(850, 60),
                Size = new Size(300, 150),
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                ForeColor = Color.FromArgb(70, 130, 180)
            };
            panelPrincipal.Controls.Add(groupBoxCliente);

            btnEditarCliente = CriarButton("Editar Cliente", new Point(20, 30), BtnEditarCliente_Click, false);
            groupBoxCliente.Controls.Add(btnEditarCliente);

            btnAdicionarAnimal = CriarButton("Adicionar Animal", new Point(20, 80), BtnAdicionarAnimal_Click, false);
            groupBoxCliente.Controls.Add(btnAdicionarAnimal);

            GroupBox groupBoxAnimal = new GroupBox
            {
                Text = "Ações do Animal",
                Location = new Point(850, 320),
                Size = new Size(300, 190), // Aumentar a altura para 190
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                ForeColor = Color.FromArgb(70, 130, 180)
            };
            panelPrincipal.Controls.Add(groupBoxAnimal);

            btnAdicionarServico = CriarButton("Adicionar Serviço", new Point(20, 30), BtnAdicionarServico_Click, false);
            groupBoxAnimal.Controls.Add(btnAdicionarServico);

            btnDarBaixaAnimal = CriarButton("Dar Baixa Animal", new Point(20, 80), BtnDarBaixaAnimal_Click, false);
            groupBoxAnimal.Controls.Add(btnDarBaixaAnimal);

            btnVerAnimaisInativos = CriarButton("Ver Animais Inativos", new Point(20, 130), BtnVerAnimaisInativos_Click);
            groupBoxAnimal.Controls.Add(btnVerAnimaisInativos);
        }

        private Panel CriarPanel()
        {
            return new Panel
            {
                Size = new Size(1160, 730),
                Location = new Point(20, 20),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.White
            };
        }

        private TextBox CriarTextBox(Point location, Size size, string placeholder)
        {
            return new TextBox
            {
                Location = location,
                Size = size,
                Text = placeholder,
                ForeColor = Color.Gray,
                Font = new Font("Segoe UI", 10, FontStyle.Regular)
            };
        }

        private DataGridView CriarDataGridView(Point location, Size size, string[] columnNames)
        {
            var dgv = new DataGridView
            {
                Location = location,
                Size = size,
                AllowUserToAddRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.FromArgb(45, 45, 48),
                    ForeColor = Color.White,
                    Font = new Font("Segoe UI", 10, FontStyle.Bold)
                },
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.White,
                    ForeColor = Color.Black,
                    Font = new Font("Segoe UI", 10, FontStyle.Regular),
                    SelectionBackColor = Color.FromArgb(0, 122, 204),
                    SelectionForeColor = Color.White
                },
                EnableHeadersVisualStyles = false,
                ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single,
                CellBorderStyle = DataGridViewCellBorderStyle.Single,
                GridColor = Color.FromArgb(230, 230, 230)
            };

            foreach (var columnName in columnNames)
            {
                dgv.Columns.Add(columnName, columnName);
                if (columnName.StartsWith("id")) dgv.Columns[columnName].Visible = false;
            }

            return dgv;
        }

        private Label CriarLabel(string text, Point location)
        {
            return new Label
            {
                Text = text,
                Location = location,
                Size = new Size(300, 20),
                Font = new Font("Segoe UI", 10, FontStyle.Regular),
                ForeColor = Color.FromArgb(70, 130, 180)
            };
        }

        private Button CriarButton(string text, Point location, EventHandler clickEvent, bool enabled = true)
        {
            var btn = new Button
            {
                Text = text,
                Location = location,
                Size = new Size(250, 40),
                Enabled = enabled,
                BackColor = Color.FromArgb(100, 149, 237),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 12, FontStyle.Bold)
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.Click += clickEvent;
            btn.Paint += (sender, e) =>
            {
                var button = sender as Button;
                var rect = new Rectangle(0, 0, button.Width, button.Height);
                var path = new System.Drawing.Drawing2D.GraphicsPath();
                int radius = 10;
                path.AddArc(rect.X, rect.Y, radius, radius, 180, 90);
                path.AddArc(rect.X + rect.Width - radius, rect.Y, radius, radius, 270, 90);
                path.AddArc(rect.X + rect.Width - radius, rect.Y + rect.Height - radius, radius, radius, 0, 90);
                path.AddArc(rect.X, rect.Y + rect.Height - radius, radius, radius, 90, 90);
                button.Region = new Region(path);
            };
            return btn;
        }

        private void TxtPesquisar_Enter(object sender, EventArgs e)
        {
            if (txtPesquisar.Text == "Pesquisar por Nome, NIF ou Telefone...")
            {
                txtPesquisar.Text = "";
                txtPesquisar.ForeColor = Color.Black;
            }
        }

        private void TxtPesquisar_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtPesquisar.Text))
            {
                txtPesquisar.Text = "Pesquisar por Nome, NIF ou Telefone...";
                txtPesquisar.ForeColor = Color.Gray;
            }
        }

        private void CarregarClientes(string filtro = "")
        {
            using (var conexao = ligarBD.GetConnection())
            {
                conexao.Open();
                string query = "SELECT idCliente, Nome, NIF, Telefone FROM Cliente" +
                               (!string.IsNullOrEmpty(filtro) ? " WHERE Nome LIKE @filtro OR NIF LIKE @filtro OR Telefone LIKE @filtro" : "");
                using (var cmd = new MySqlCommand(query, conexao))
                {
                    if (!string.IsNullOrEmpty(filtro))
                    {
                        cmd.Parameters.AddWithValue("@filtro", "%" + filtro + "%");
                    }
                    using (var reader = cmd.ExecuteReader())
                    {
                        dgvClientes.Rows.Clear();
                        while (reader.Read())
                        {
                            dgvClientes.Rows.Add(reader["idCliente"], reader["Nome"], reader["NIF"], reader["Telefone"]);
                        }
                    }
                }
            }
        }

        private void TxtPesquisar_TextChanged(object sender, EventArgs e)
        {
            CarregarClientes(txtPesquisar.Text.Trim());
        }

        private void DgvClientes_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvClientes.SelectedRows.Count > 0)
            {
                var row = dgvClientes.SelectedRows[0];
                lblClienteSelecionado.Text = $"Cliente Selecionado: {row.Cells["Nome"].Value}";
                idClienteSelecionado = Convert.ToInt32(row.Cells["idCliente"].Value);
                CarregarAnimais(idClienteSelecionado);
                btnAdicionarAnimal.Enabled = btnEditarCliente.Enabled = true;
            }
            else
            {
                ResetarSelecao();
            }
        }

        private void CarregarAnimais(int idCliente)
        {
            using (var conexao = ligarBD.GetConnection())
            {
                conexao.Open();
                string query = "SELECT idAnimal, NomeAnimal, Raca, Observacoes FROM Animal WHERE idCliente = @idCliente AND ativo = 1";
                using (var cmd = new MySqlCommand(query, conexao))
                {
                    cmd.Parameters.AddWithValue("@idCliente", idCliente);
                    using (var reader = cmd.ExecuteReader())
                    {
                        dgvAnimais.Rows.Clear();
                        while (reader.Read())
                        {
                            dgvAnimais.Rows.Add(reader["idAnimal"], reader["NomeAnimal"], reader["Raca"], reader["Observacoes"]);
                        }
                    }
                }
            }
        }

        private void DgvAnimais_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvAnimais.SelectedRows.Count > 0)
            {
                var row = dgvAnimais.SelectedRows[0];
                lblAnimalSelecionado.Text = $"Animal Selecionado: {row.Cells["NomeAnimal"].Value}";
                idAnimalSelecionado = Convert.ToInt32(row.Cells["idAnimal"].Value);
                CarregarServicos(idAnimalSelecionado);
                btnAdicionarServico.Enabled = btnDarBaixaAnimal.Enabled = true;
            }
            else
            {
                lblAnimalSelecionado.Text = "Animal Selecionado: Nenhum";
                dgvServicos.Rows.Clear();
                btnAdicionarServico.Enabled = btnDarBaixaAnimal.Enabled = false;
            }
        }

        private void CarregarServicos(int idAnimal)
        {
            using (var conexao = ligarBD.GetConnection())
            {
                conexao.Open();
                string query = "SELECT data AS DataServico, descricao, preco AS Preco FROM registoservicos INNER JOIN servico ON registoservicos.idServico = servico.idServico WHERE idAnimal = @idAnimal";
                using (var cmd = new MySqlCommand(query, conexao))
                {
                    cmd.Parameters.AddWithValue("@idAnimal", idAnimal);
                    using (var reader = cmd.ExecuteReader())
                    {
                        dgvServicos.Rows.Clear();
                        while (reader.Read())
                        {
                            dgvServicos.Rows.Add(Convert.ToDateTime(reader["DataServico"]).ToString("dd/MM/yyyy"), reader["descricao"], reader["Preco"]);
                        }
                    }
                }
            }
        }

        private void BtnAdicionarServico_Click(object sender, EventArgs e)
        {
            if (dgvAnimais.SelectedRows.Count == 0)
            {
                MessageBox.Show("Selecione um animal antes de adicionar um serviço.");
                return;
            }

            var rowAnimal = dgvAnimais.SelectedRows[0];
            int idAnimalSelecionado = Convert.ToInt32(rowAnimal.Cells["idAnimal"].Value);
            var adicionarServicoForm = new AdicionarServico(idAnimalSelecionado);

            adicionarServicoForm.FormClosed += (s, args) =>
            {
                CarregarServicos(idAnimalSelecionado); // Atualiza a tabela de serviços
            };

            adicionarServicoForm.ShowDialog();
        }

        private void BtnAdicionarAnimal_Click(object sender, EventArgs e)
        {
            if (idClienteSelecionado == 0)
            {
                MessageBox.Show("Selecione um cliente antes de adicionar um animal.");
                return;
            }

            var adicionarAnimalForm = new AdicionarAnimal(idClienteSelecionado);
            adicionarAnimalForm.ShowDialog();
            if (adicionarAnimalForm.DialogResult == DialogResult.OK)
            {
                CarregarAnimais(idClienteSelecionado);
            }
        }

        private void BtnEditarCliente_Click(object sender, EventArgs e)
        {
            if (idClienteSelecionado == 0)
            {
                MessageBox.Show("Selecione um cliente antes de editar.");
                return;
            }

            var editarClienteForm = new FormEditarCliente(idClienteSelecionado);
            editarClienteForm.ShowDialog();
            CarregarClientes();
        }

        private void BtnDarBaixaAnimal_Click(object sender, EventArgs e)
        {
            if (idAnimalSelecionado == 0)
            {
                MessageBox.Show("Selecione um animal antes de dar baixa.");
                return;
            }

            using (var conexao = ligarBD.GetConnection())
            {
                conexao.Open();
                string query = "UPDATE Animal SET ativo = 0 WHERE idAnimal = @idAnimal";
                using (var cmd = new MySqlCommand(query, conexao))
                {
                    cmd.Parameters.AddWithValue("@idAnimal", idAnimalSelecionado);
                    cmd.ExecuteNonQuery();
                }
            }

            MessageBox.Show("Animal dado de baixa com sucesso.");
            CarregarAnimais(idClienteSelecionado);
        }

        private void BtnVerAnimaisInativos_Click(object sender, EventArgs e)
        {
            var verAnimaisInativosForm = new VerAnimaisInativos();
            verAnimaisInativosForm.AnimalReativado += () => CarregarAnimais(idClienteSelecionado); // Inscreva-se no evento
            verAnimaisInativosForm.ShowDialog();
        }

        private void SalvarServicoNoBanco(int idAnimal, int idServico, DateTime dataServico, decimal precoServico, string observacoesServico)
        {
            using (var conexao = ligarBD.GetConnection())
            {
                conexao.Open();
                string query = "INSERT INTO registoservicos (idAnimal, idServico, data, observacoes, preco) VALUES (@idAnimal, @idServico, @data, @observacoes, @preco)";
                using (var cmd = new MySqlCommand(query, conexao))
                {
                    cmd.Parameters.AddWithValue("@idAnimal", idAnimal);
                    cmd.Parameters.AddWithValue("@idServico", idServico);
                    cmd.Parameters.AddWithValue("@data", dataServico);
                    cmd.Parameters.AddWithValue("@observacoes", observacoesServico);
                    cmd.Parameters.AddWithValue("@preco", precoServico);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private void ConsultarCliente_Load(object sender, EventArgs e)
        {

        }

        private void ResetarSelecao()
        {
            lblClienteSelecionado.Text = "Cliente Selecionado: Nenhum";
            dgvAnimais.Rows.Clear();
            dgvServicos.Rows.Clear();
            btnAdicionarServico.Enabled = btnAdicionarAnimal.Enabled = btnEditarCliente.Enabled = btnDarBaixaAnimal.Enabled = false;
        }
    }
}