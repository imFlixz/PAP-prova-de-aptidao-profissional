﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace VaiDarBanhoOCao
{
    public partial class VerServicosRealizados : Form
    {
        private Label lblTotalFaturado; // Label para exibir o total faturado
        private TextBox txtCliente;    // Campo de pesquisa com autocomplete para clientes

        public VerServicosRealizados()
        {
            InitializeComponent();
            AplicarEstilo();
            InitializeCustomComponents(); // Inicializar os componentes personalizados
        }

        private void VerServicosRealizados_Load(object sender, EventArgs e)
        {
            DataTable servicosRealizados = ObterServicosRealizados(null, null, null, null);
            dgvServicosRealizados.DataSource = servicosRealizados;
            CarregarServicos();
            CarregarMeses();
            ConfigurarAutoCompleteClientes();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            string servico = cbServico.SelectedItem != null && cbServico.SelectedIndex != 0 ? cbServico.SelectedItem.ToString() : null;
            string data = dtpData.Checked ? dtpData.Value.ToString("yyyy-MM-dd") : null;
            string mesAno = cbMes.SelectedItem != null && cbMes.SelectedIndex != 0 && nudAno.Value > 0 ? $"{nudAno.Value}-{cbMes.SelectedIndex:00}" : null;
            string clienteNome = !string.IsNullOrEmpty(txtCliente.Text) ? txtCliente.Text : null;

            DataTable servicosRealizados = ObterServicosRealizados(servico, data, mesAno, clienteNome);
            dgvServicosRealizados.DataSource = servicosRealizados;

            if (!string.IsNullOrEmpty(mesAno))
            {
                decimal totalFaturado = CalcularTotalFaturado(mesAno);
                lblTotalFaturado.Text = $"Total Faturado: {totalFaturado:C}";
            }
        }

        private DataTable ObterServicosRealizados(string servico, string data, string mesAno, string clienteNome)
        {
            DataTable table = new DataTable();
            string connectionString = "Server=localhost; Database=pap_cao; Uid=root; Pwd=;";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = @"SELECT 
                                        servico.descricao AS 'Nome do Serviço', 
                                        registoservicos.data AS Data, 
                                        cliente.nome AS Cliente,
                                        registoservicos.preco AS Preço 
                                     FROM registoservicos 
                                     JOIN servico ON registoservicos.idServico = servico.idServico
                                     JOIN animal ON registoservicos.idAnimal = animal.idAnimal
                                     JOIN cliente ON animal.idCliente = cliente.idCliente
                                     WHERE (@servico IS NULL OR servico.descricao LIKE CONCAT('%', @servico, '%'))
                                     AND (@data IS NULL OR registoservicos.data = @data)
                                     AND (@mesAno IS NULL OR DATE_FORMAT(registoservicos.data, '%Y-%m') = @mesAno)
                                     AND (@clienteNome IS NULL OR cliente.nome LIKE CONCAT('%', @clienteNome, '%'))";
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@servico", string.IsNullOrEmpty(servico) ? (object)DBNull.Value : servico);
                    cmd.Parameters.AddWithValue("@data", string.IsNullOrEmpty(data) ? (object)DBNull.Value : data);
                    cmd.Parameters.AddWithValue("@mesAno", string.IsNullOrEmpty(mesAno) ? (object)DBNull.Value : mesAno);
                    cmd.Parameters.AddWithValue("@clienteNome", string.IsNullOrEmpty(clienteNome) ? (object)DBNull.Value : clienteNome);
                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    adapter.Fill(table);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao carregar serviços realizados: " + ex.Message);
                }
            }

            return table;
        }

        private decimal CalcularTotalFaturado(string mesAno)
        {
            decimal total = 0;
            string connectionString = "Server=localhost; Database=pap_cao; Uid=root; Pwd=;";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = @"SELECT SUM(registoservicos.preco) AS TotalFaturado
                                     FROM registoservicos
                                     WHERE DATE_FORMAT(registoservicos.data, '%Y-%m') = @mesAno";
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@mesAno", mesAno);
                    object result = cmd.ExecuteScalar();
                    if (result != DBNull.Value)
                    {
                        total = Convert.ToDecimal(result);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao calcular o total faturado: " + ex.Message);
                }
            }

            return total;
        }

        private void CarregarServicos()
        {
            cbServico.Items.Add("Serviços:");
            string connectionString = "Server=localhost; Database=pap_cao; Uid=root; Pwd=;";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT descricao FROM servico";
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        cbServico.Items.Add(reader["descricao"].ToString());
                    }
                    cbServico.SelectedIndex = 0;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao carregar serviços: " + ex.Message);
                }
            }
        }

        private void CarregarMeses()
        {
            cbMes.Items.Add("Mês:");
            cbMes.Items.AddRange(new string[]
            {
                "Janeiro", "Fevereiro", "Março", "Abril", "Maio",
                "Junho", "Julho", "Agosto", "Setembro", "Outubro",
                "Novembro", "Dezembro"
            });
            cbMes.SelectedIndex = 0;
            nudAno.Value = DateTime.Now.Year;
        }

        private void ConfigurarAutoCompleteClientes()
        {
            AutoCompleteStringCollection clienteCollection = new AutoCompleteStringCollection();
            string connectionString = "Server=localhost; Database=pap_cao; Uid=root; Pwd=;";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT nome FROM cliente";
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        clienteCollection.Add(reader["nome"].ToString());
                    }
                    txtCliente.AutoCompleteCustomSource = clienteCollection;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao carregar clientes: " + ex.Message);
                }
            }
        }

        private void AplicarEstilo()
        {
            this.BackColor = Color.FromArgb(240, 248, 255); // Tema de cor relaxante
            this.ForeColor = Color.Black;
            dgvServicosRealizados.BackgroundColor = Color.White;
            dgvServicosRealizados.DefaultCellStyle.BackColor = Color.White;
            dgvServicosRealizados.DefaultCellStyle.ForeColor = Color.Black;
            dgvServicosRealizados.DefaultCellStyle.SelectionBackColor = Color.FromArgb(0, 122, 204);
            dgvServicosRealizados.DefaultCellStyle.SelectionForeColor = Color.White;

            EstiloBotao(btnPesquisar);
        }

        private void EstiloBotao(Button button)
        {
            button.BackColor = Color.FromArgb(100, 149, 237);
            button.ForeColor = Color.White;
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.Font = new Font("Segoe UI", 12, FontStyle.Bold);
            button.Size = new Size(button.Width + 20, button.Height + 10);
            button.Paint += (sender, e) =>
            {
                var btn = sender as Button;
                var rect = new Rectangle(0, 0, btn.Width, btn.Height);
                var path = new System.Drawing.Drawing2D.GraphicsPath();
                int radius = 10;
                path.AddArc(rect.X, rect.Y, radius, radius, 180, 90);
                path.AddArc(rect.X + rect.Width - radius, rect.Y, radius, radius, 270, 90);
                path.AddArc(rect.X + rect.Width - radius, rect.Y + rect.Height - radius, radius, radius, 0, 90);
                path.AddArc(rect.X, rect.Y + rect.Height - radius, radius, radius, 90, 90);
                path.CloseFigure();
                btn.Region = new Region(path);
            };
        }

        private void InitializeCustomComponents()
        {
            lblTotalFaturado = new Label
            {
                AutoSize = true,
                Location = new Point(20, 20),
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                ForeColor = Color.Black
            };
            this.Controls.Add(lblTotalFaturado);

            // Configurar o TextBox para o cliente
            txtCliente = new TextBox
            {
                Location = new Point(710, 50), // Ajustado para alinhar com outros controles
                Width = 200,
                Font = new Font("Segoe UI", 12)
            };

            txtCliente.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            txtCliente.AutoCompleteSource = AutoCompleteSource.CustomSource;
            this.Controls.Add(txtCliente);
        }
    }
}