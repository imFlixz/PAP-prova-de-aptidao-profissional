﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace VaiDarBanhoOCao
{
    public partial class AdicionarCliente : Form
    {
        MySqlConnection ligar = ligarBD.GetConnection();
        private TextBox txtNome, txtNIF, txtTelemovel, txtEmail, txtMorada;

        private void AdicionarCliente_Load(object sender, EventArgs e) { }

        public AdicionarCliente()
        {
            InitializeComponent();
            ConfigurarFormulario();
        }

        public static class ligarBD
        {
            public static MySqlConnection GetConnection()
            {
                string servidor = "localhost";
                string bancoDeDados = "pap_cao";
                string usuario = "root";
                string senha = "";
                string conexaoString = $"Server={servidor}; Database={bancoDeDados}; Uid={usuario}; Pwd={senha};";
                return new MySqlConnection(conexaoString);
            }
        }

        private void ConfigurarFormulario()
        {
            this.Text = "Adicionar Cliente";
            this.Size = new Size(600, 500);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 248, 255); // Tema de cor relaxante

            Label lblTitulo = new Label
            {
                Text = "Adicionar Cliente",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(70, 130, 180),
                AutoSize = true,
                Location = new Point(20, 20)
            };
            this.Controls.Add(lblTitulo);

            GroupBox gbCliente = new GroupBox
            {
                Text = "Informações do Cliente",
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                Size = new Size(550, 240),
                Location = new Point(20, 60)
            };
            this.Controls.Add(gbCliente);

            txtNome = CriarLabelETxtBox(gbCliente, "Nome:", 20, 30);
            txtNIF = CriarLabelETxtBox(gbCliente, "NIF:", 20, 70);
            txtTelemovel = CriarLabelETxtBox(gbCliente, "Telemóvel:", 20, 110);
            txtEmail = CriarLabelETxtBox(gbCliente, "Email:", 20, 150);
            txtMorada = CriarLabelETxtBox(gbCliente, "Morada:", 20, 190);

            Button btnSalvar = new Button
            {
                Text = "Salvar",
                Size = new Size(120, 40),
                BackColor = Color.FromArgb(100, 149, 237),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                Location = new Point(270, 350)
            };
            btnSalvar.FlatAppearance.BorderSize = 0;
            btnSalvar.Paint += (sender, e) =>
            {
                var btn = sender as Button;
                var rect = new Rectangle(0, 0, btn.Width, btn.Height);
                var path = new System.Drawing.Drawing2D.GraphicsPath();
                int radius = 20;
                path.AddArc(rect.X, rect.Y, radius, radius, 180, 90);
                path.AddArc(rect.X + rect.Width - radius, rect.Y, radius, radius, 270, 90);
                path.AddArc(rect.X + rect.Width - radius, rect.Y + rect.Height - radius, radius, radius, 0, 90);
                path.AddArc(rect.X, rect.Y + rect.Height - radius, radius, radius, 90, 90);
                btn.Region = new Region(path);
            };
            btnSalvar.Click += BtnSalvar_Click;
            this.Controls.Add(btnSalvar);

            Button btnCancelar = new Button
            {
                Text = "Cancelar",
                Size = new Size(120, 40),
                BackColor = Color.Gray,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                Location = new Point(400, 350)
            };
            btnCancelar.FlatAppearance.BorderSize = 0;
            btnCancelar.Paint += (sender, e) =>
            {
                var btn = sender as Button;
                var rect = new Rectangle(0, 0, btn.Width, btn.Height);
                var path = new System.Drawing.Drawing2D.GraphicsPath();
                int radius = 20;
                path.AddArc(rect.X, rect.Y, radius, radius, 180, 90);
                path.AddArc(rect.X + rect.Width - radius, rect.Y, radius, radius, 270, 90);
                path.AddArc(rect.X + rect.Width - radius, rect.Y + rect.Height - radius, radius, radius, 0, 90);
                path.AddArc(rect.X, rect.Y + rect.Height - radius, radius, radius, 90, 90);
                btn.Region = new Region(path);
            };
            btnCancelar.Click += (s, e) => this.Close();
            this.Controls.Add(btnCancelar);
        }

        private void BtnSalvar_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtNome.Text))
                {
                    MessageBox.Show("O campo Nome é obrigatório.", "Erro de Validação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtNIF.Text) || txtNIF.Text.Length != 9 || !txtNIF.Text.All(char.IsDigit))
                {
                    MessageBox.Show("O campo NIF é obrigatório e deve conter exatamente 9 números.", "Erro de Validação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtTelemovel.Text) || txtTelemovel.Text.Length != 9 || !txtTelemovel.Text.All(char.IsDigit))
                {
                    MessageBox.Show("O campo Telemóvel é obrigatório e deve conter exatamente 9 números.", "Erro de Validação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtEmail.Text) || !txtEmail.Text.Contains("@"))
                {
                    MessageBox.Show("Escreva um email válido.", "Erro de Validação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtMorada.Text))
                {
                    MessageBox.Show("O campo Morada é obrigatório.", "Erro de Validação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                ligar.Open();
                string sqlCliente = "INSERT INTO cliente (nome, nif, telefone, email, morada) VALUES (@nome, @nif, @telefone, @email, @morada)";
                MySqlCommand cmdCliente = new MySqlCommand(sqlCliente, ligar);
                cmdCliente.Parameters.AddWithValue("@nome", txtNome.Text);
                cmdCliente.Parameters.AddWithValue("@nif", txtNIF.Text);
                cmdCliente.Parameters.AddWithValue("@telefone", txtTelemovel.Text);
                cmdCliente.Parameters.AddWithValue("@email", txtEmail.Text);
                cmdCliente.Parameters.AddWithValue("@morada", txtMorada.Text);
                cmdCliente.ExecuteNonQuery();

                MessageBox.Show("Cliente adicionado com sucesso!");
                this.Close(); // Fechar o formulário após adicionar o cliente
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao salvar dados: {ex.Message}");
            }
            finally
            {
                ligar.Close();
            }
        }

        private TextBox CriarLabelETxtBox(Control parent, string labelTexto, int x, int y)
        {
            Label lbl = new Label
            {
                Text = labelTexto,
                Font = new Font("Segoe UI", 10F),
                AutoSize = true,
                Location = new Point(x, y),
                ForeColor = Color.FromArgb(70, 130, 180)
            };
            parent.Controls.Add(lbl);

            TextBox txt = new TextBox
            {
                Size = new Size(350, 30),
                Font = new Font("Segoe UI", 10F),
                Location = new Point(x + 150, y - 5)
            };
            parent.Controls.Add(txt);

            return txt;
        }
    }
}