﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace VaiDarBanhoOCao
{
    public partial class VerTipoServico : Form
    {
        private List<string> services;

        public VerTipoServico()
        {
            InitializeComponent();
            services = new List<string>();
            AplicarEstilo();
        }

        private void VerTipoServico_Load(object sender, EventArgs e)
        {
            DataTable servicesData = ObterTiposDeServicos();
            foreach (DataRow row in servicesData.Rows)
            {
                services.Add(row["descricao"].ToString());
            }
            UpdateServiceGrid();
        }

        private void btnAddService_Click(object sender, EventArgs e)
        {
            string newService = txtServiceName.Text.Trim();

            if (!string.IsNullOrEmpty(newService) && !services.Contains(newService))
            {
                services.Add(newService);
                AdicionarServicoNoBanco(newService);
                UpdateServiceGrid();
                txtServiceName.Clear();
            }
            else
            {
                MessageBox.Show("O serviço já existe ou o campo está vazio.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRemoveService_Click(object sender, EventArgs e)
        {
            if (dgvServices.SelectedRows.Count > 0)
            {
                string serviceToRemove = dgvServices.SelectedRows[0].Cells[0].Value.ToString();

                // Verificar se o serviço está associado a algum registro
                if (ServicoAssociado(serviceToRemove))
                {
                    MessageBox.Show("Não é possível remover este serviço, pois ele está associado a registros existentes.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                services.Remove(serviceToRemove);
                RemoverServicoDoBanco(serviceToRemove);
                UpdateServiceGrid();
            }
            else
            {
                MessageBox.Show("Selecione um serviço para remover.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateServiceGrid()
        {
            dgvServices.Rows.Clear();

            foreach (string service in services)
            {
                dgvServices.Rows.Add(service);
            }
        }

        private DataTable ObterTiposDeServicos()
        {
            DataTable table = new DataTable();
            string connectionString = "Server=localhost; Database=pap_cao; Uid=root; Pwd=;";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT descricao FROM servico";
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    adapter.Fill(table);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao carregar tipos de serviços: " + ex.Message);
                }
            }

            return table;
        }

        private void AdicionarServicoNoBanco(string descricao)
        {
            string connectionString = "Server=localhost; Database=pap_cao; Uid=root; Pwd=;";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "INSERT INTO servico (descricao) VALUES (@descricao)";
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@descricao", descricao);
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao adicionar serviço: " + ex.Message);
                }
            }
        }

        private void RemoverServicoDoBanco(string descricao)
        {
            string connectionString = "Server=localhost; Database=pap_cao; Uid=root; Pwd=;";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "DELETE FROM servico WHERE descricao = @descricao";
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@descricao", descricao);
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao remover serviço: " + ex.Message);
                }
            }
        }

        private bool ServicoAssociado(string descricao)
        {
            bool associado = false;
            string connectionString = "Server=localhost; Database=pap_cao; Uid=root; Pwd=;";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT COUNT(*) FROM registoservicos WHERE idServico = (SELECT idServico FROM servico WHERE descricao = @descricao)";
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@descricao", descricao);
                    associado = Convert.ToInt32(cmd.ExecuteScalar()) > 0;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao verificar associação do serviço: " + ex.Message);
                }
            }

            return associado;
        }

        private void AplicarEstilo()
        {
            this.BackColor = Color.FromArgb(240, 248, 255); // Tema de cor relaxante
            this.ForeColor = Color.Black;
            dgvServices.BackgroundColor = Color.White;
            dgvServices.DefaultCellStyle.BackColor = Color.White;
            dgvServices.DefaultCellStyle.ForeColor = Color.Black;
            dgvServices.DefaultCellStyle.SelectionBackColor = Color.FromArgb(0, 122, 204);
            dgvServices.DefaultCellStyle.SelectionForeColor = Color.White;

            EstiloBotao(btnAddService);
            EstiloBotao(btnRemoveService);

            txtServiceName.Enter += TxtServiceName_Enter;
            txtServiceName.Leave += TxtServiceName_Leave;
        }

        private void EstiloBotao(Button button)
        {
            button.BackColor = Color.FromArgb(100, 149, 237);
            button.ForeColor = Color.White;
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.Font = new Font("Segoe UI", 12, FontStyle.Bold); // Aumentei o tamanho da fonte
            button.Size = new Size(button.Width + 20, button.Height + 10); // Aumentei o tamanho do botão
            button.Paint += (sender, e) =>
            {
                var btn = sender as Button;
                var rect = new Rectangle(0, 0, btn.Width, btn.Height);
                var path = new System.Drawing.Drawing2D.GraphicsPath();
                int radius = 10;
                path.AddArc(rect.X, rect.Y, radius, radius, 180, 90);
                path.AddArc(rect.X + rect.Width - radius, rect.Y, radius, radius, 270, 90);
                path.AddArc(rect.X + rect.Width - radius, rect.Y + rect.Height - radius, radius, radius, 0, 90);
                path.AddArc(rect.X, rect.Y + rect.Height - radius, radius, radius, 90, 90);
                path.CloseFigure();
                btn.Region = new Region(path);
            };
        }

        private void TxtServiceName_Enter(object sender, EventArgs e)
        {
            if (txtServiceName.Text == "Nome do Serviço")
            {
                txtServiceName.Text = "";
                txtServiceName.ForeColor = Color.Black;
            }
        }

        private void TxtServiceName_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtServiceName.Text))
            {
                txtServiceName.Text = "Nome do Serviço";
                txtServiceName.ForeColor = Color.Gray;
            }
        }
    }
}