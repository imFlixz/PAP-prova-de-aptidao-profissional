﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace VaiDarBanhoOCao
{
    public partial class RegistoTransacoes : Form
    {
        public RegistoTransacoes()
        {
            InitializeComponent();
            AplicarEstilo();
        }

        private void RegistoTransacoes_Load(object sender, EventArgs e)
        {
            CarregarProdutos();
            ConfigurarClientesAutoComplete();
            CarregarTransacoes();
            AplicarEstiloBotaoArredondado(btnAdicionarTransacao);
        }

        private void CarregarProdutos()
        {
            string connectionString = "Server=localhost; Database=pap_cao; Uid=root; Pwd=;";
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT nome FROM produto";
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader reader = cmd.ExecuteReader();
                    cbProdutos.Items.Add("Produto:");
                    while (reader.Read())
                    {
                        cbProdutos.Items.Add(reader["nome"].ToString());
                    }
                    cbProdutos.SelectedIndex = 0;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao carregar produtos: " + ex.Message);
                }
            }
        }

        private void ConfigurarClientesAutoComplete()
        {
            AutoCompleteStringCollection clienteCollection = new AutoCompleteStringCollection();
            string connectionString = "Server=localhost; Database=pap_cao; Uid=root; Pwd=;";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT nome FROM cliente";
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        clienteCollection.Add(reader["nome"].ToString());
                    }

                    txtClientes.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    txtClientes.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    txtClientes.AutoCompleteCustomSource = clienteCollection;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao carregar clientes: " + ex.Message);
                }
            }
        }

        private void btnAdicionarTransacao_Click(object sender, EventArgs e)
        {
            string produto = cbProdutos.SelectedItem != null && cbProdutos.SelectedIndex != 0
                ? cbProdutos.SelectedItem.ToString()
                : null;

            string cliente = txtClientes.Text;

            if (string.IsNullOrWhiteSpace(cliente) || produto == null || !int.TryParse(txtQuantidade.Text, out int quantidade))
            {
                MessageBox.Show("Por favor, selecione um cliente, um produto e insira uma quantidade válida.");
                return;
            }

            string connectionString = "Server=localhost; Database=pap_cao; Uid=root; Pwd=;";
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    // Buscar o ID do cliente
                    string query = "SELECT idCliente FROM cliente WHERE nome = @nome";
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@nome", cliente);
                    object result = cmd.ExecuteScalar();

                    if (result == null)
                    {
                        MessageBox.Show("Cliente não encontrado.");
                        return;
                    }

                    int idCliente = Convert.ToInt32(result);

                    // Buscar informações do produto
                    query = "SELECT idProduto, precoUnitario, quantidadeEmStock FROM produto WHERE nome = @nome";
                    cmd = new MySqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@nome", produto);
                    MySqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        int idProduto = Convert.ToInt32(reader["idProduto"]);
                        decimal precoUnitario = Convert.ToDecimal(reader["precoUnitario"]);
                        int quantidadeEmStock = Convert.ToInt32(reader["quantidadeEmStock"]);

                        if (quantidade > quantidadeEmStock)
                        {
                            MessageBox.Show($"Quantidade insuficiente em stock. Estoque atual: {quantidadeEmStock} unidades.");
                            return;
                        }

                        reader.Close();

                        // Registrar a venda
                        query = "INSERT INTO vendaproduto (idCliente, idProduto, quantidade, precoUnitario, total, dataVenda) VALUES (@idCliente, @idProduto, @quantidade, @precoUnitario, @total, @dataVenda)";
                        cmd = new MySqlCommand(query, connection);
                        cmd.Parameters.AddWithValue("@idCliente", idCliente);
                        cmd.Parameters.AddWithValue("@idProduto", idProduto);
                        cmd.Parameters.AddWithValue("@quantidade", quantidade);
                        cmd.Parameters.AddWithValue("@precoUnitario", precoUnitario);
                        cmd.Parameters.AddWithValue("@total", quantidade * precoUnitario);
                        cmd.Parameters.AddWithValue("@dataVenda", dtpData.Value);
                        cmd.ExecuteNonQuery();

                        // Atualizar o estoque
                        query = "UPDATE produto SET quantidadeEmStock = quantidadeEmStock - @quantidade WHERE idProduto = @idProduto";
                        cmd = new MySqlCommand(query, connection);
                        cmd.Parameters.AddWithValue("@quantidade", quantidade);
                        cmd.Parameters.AddWithValue("@idProduto", idProduto);
                        cmd.ExecuteNonQuery();

                        CarregarTransacoes();
                        MessageBox.Show("Transação registrada com sucesso.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao registrar transação: " + ex.Message);
                }
            }
        }

        private void CarregarTransacoes()
        {
            string connectionString = "Server=localhost; Database=pap_cao; Uid=root; Pwd=;";
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = @"SELECT 
                                        vendaproduto.dataVenda AS Data, 
                                        cliente.nome AS Cliente, 
                                        produto.nome AS Produto, 
                                        vendaproduto.quantidade AS Quantidade, 
                                        vendaproduto.total AS 'Valor Total' 
                                     FROM vendaproduto 
                                     JOIN produto ON vendaproduto.idProduto = produto.idProduto
                                     JOIN cliente ON vendaproduto.idCliente = cliente.idCliente";
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    dgvTransacoes.DataSource = table;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao carregar transações: " + ex.Message);
                }
            }
        }

        private void AplicarEstilo()
        {
            this.BackColor = Color.FromArgb(240, 248, 255); // Tema de cor relaxante
            this.ForeColor = Color.Black;
            dgvTransacoes.BackgroundColor = Color.White;
            dgvTransacoes.DefaultCellStyle.BackColor = Color.White;
            dgvTransacoes.DefaultCellStyle.ForeColor = Color.Black;
            dgvTransacoes.DefaultCellStyle.SelectionBackColor = Color.FromArgb(0, 122, 204);
            dgvTransacoes.DefaultCellStyle.SelectionForeColor = Color.White;
        }

        private void AplicarEstiloBotaoArredondado(Button button)
        {
            button.Paint += (sender, e) =>
            {
                var btn = sender as Button;
                var rect = new Rectangle(0, 0, btn.Width, btn.Height);
                var path = new System.Drawing.Drawing2D.GraphicsPath();
                int radius = 20; // Raio para as bordas arredondadas
                path.AddArc(rect.X, rect.Y, radius, radius, 180, 90);
                path.AddArc(rect.Right - radius, rect.Y, radius, radius, 270, 90);
                path.AddArc(rect.Right - radius, rect.Bottom - radius, radius, radius, 0, 90);
                path.AddArc(rect.X, rect.Bottom - radius, radius, radius, 90, 90);
                path.CloseFigure();
                btn.Region = new Region(path);
            };

            button.BackColor = Color.FromArgb(100, 149, 237); // Azul claro
            button.ForeColor = Color.White;
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.Font = new Font("Segoe UI", 12, FontStyle.Bold);
        }

        private void TxtQuantidade_Enter(object sender, EventArgs e)
        {
            if (txtQuantidade.Text == "Quantidade")
            {
                txtQuantidade.Text = "";
                txtQuantidade.ForeColor = Color.Black;
            }
        }

        private void TxtQuantidade_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtQuantidade.Text))
            {
                txtQuantidade.Text = "Quantidade";
                txtQuantidade.ForeColor = Color.Gray;
            }
        }
    }
}