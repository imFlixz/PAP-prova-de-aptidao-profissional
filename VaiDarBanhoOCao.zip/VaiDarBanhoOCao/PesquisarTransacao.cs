﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace VaiDarBanhoOCao
{
    public partial class PesquisarTransacao : Form
    {
        private TextBox txtCliente; // Campo de pesquisa com autocomplete para clientes
        private ComboBox cbProduto;
        private ComboBox cbMes;
        private NumericUpDown nudAno;
        private Button btnPesquisar;
        private DataGridView dgvTransacoes;

        public PesquisarTransacao()
        {
            InitializeComponent();
            InicializarComponentesCustomizados();
            AplicarEstilo();
            CarregarClientesAutocomplete();
            CarregarProdutos();
            CarregarMeses();
            CarregarTransacoes(); // Carregar as transações automaticamente
        }

        private void PesquisarTransacao_Load(object sender, EventArgs e)
        {
        }

        private void InicializarComponentesCustomizados()
        {
            // Cliente TextBox (com autocomplete)
            txtCliente = new TextBox
            {
                Location = new Point(20, 20), // Posição no topo esquerdo
                Width = 250,
                Font = new Font("Segoe UI", 12)
            };
            txtCliente.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            txtCliente.AutoCompleteSource = AutoCompleteSource.CustomSource;
            this.Controls.Add(txtCliente);

            // Produto ComboBox
            cbProduto = new ComboBox
            {
                Location = new Point(20, 70), // Abaixo de Cliente
                Width = 250,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 12)
            };
            this.Controls.Add(cbProduto);

            // Mês ComboBox
            cbMes = new ComboBox
            {
                Location = new Point(300, 20), // Ao lado de Cliente
                Width = 150,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 12)
            };
            this.Controls.Add(cbMes);

            // Ano NumericUpDown
            nudAno = new NumericUpDown
            {
                Location = new Point(300, 70), // Abaixo de Mês
                Width = 150,
                Minimum = 2000,
                Maximum = DateTime.Now.Year,
                Value = DateTime.Now.Year,
                Font = new Font("Segoe UI", 12)
            };
            this.Controls.Add(nudAno);

            // Pesquisar Button
            btnPesquisar = new Button
            {
                Text = "Pesquisar",
                Location = new Point(480, 20), // Ao lado de Mês e Ano
                Width = 120,
                Height = 70
            };
            EstiloBotao(btnPesquisar);
            btnPesquisar.Click += BtnPesquisar_Click;
            this.Controls.Add(btnPesquisar);

            // DataGridView for displaying results
            dgvTransacoes = new DataGridView
            {
                Location = new Point(20, 150), // Abaixo dos controles de entrada
                Size = new Size(750, 350),   // Ajustado para caber completamente no formulário
                ReadOnly = true,
                AllowUserToAddRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            this.Controls.Add(dgvTransacoes);
        }

        private void AplicarEstilo()
        {
            this.BackColor = Color.FromArgb(240, 248, 255); // Tema de cor relaxante
            this.ForeColor = Color.Black;

            // Estilo para DataGridView
            dgvTransacoes.BackgroundColor = Color.White;
            dgvTransacoes.DefaultCellStyle.BackColor = Color.White;
            dgvTransacoes.DefaultCellStyle.ForeColor = Color.Black;
            dgvTransacoes.DefaultCellStyle.SelectionBackColor = Color.FromArgb(0, 122, 204);
            dgvTransacoes.DefaultCellStyle.SelectionForeColor = Color.White;
        }

        private void EstiloBotao(Button button)
        {
            button.BackColor = Color.FromArgb(100, 149, 237);
            button.ForeColor = Color.White;
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.Font = new Font("Segoe UI", 12, FontStyle.Bold);
            button.Paint += (sender, e) =>
            {
                var btn = sender as Button;
                var rect = new Rectangle(0, 0, btn.Width, btn.Height);
                var path = new System.Drawing.Drawing2D.GraphicsPath();
                int radius = 10;
                path.AddArc(rect.X, rect.Y, radius, radius, 180, 90);
                path.AddArc(rect.X + rect.Width - radius, rect.Y, radius, radius, 270, 90);
                path.AddArc(rect.X + rect.Width - radius, rect.Y + rect.Height - radius, radius, radius, 0, 90);
                path.AddArc(rect.X, rect.Y + rect.Height - radius, radius, radius, 90, 90);
                path.CloseFigure();
                btn.Region = new Region(path);
            };
        }

        private void CarregarClientesAutocomplete()
        {
            string connectionString = "Server=localhost; Database=pap_cao; Uid=root; Pwd=;";
            AutoCompleteStringCollection clienteCollection = new AutoCompleteStringCollection();

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT nome FROM cliente";
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        clienteCollection.Add(reader["nome"].ToString());
                    }
                    txtCliente.AutoCompleteCustomSource = clienteCollection;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao carregar clientes: " + ex.Message);
                }
            }
        }

        private void CarregarProdutos()
        {
            string connectionString = "Server=localhost; Database=pap_cao; Uid=root; Pwd=;";
            cbProduto.Items.Add("Todos os Produtos");
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT nome FROM produto";
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        cbProduto.Items.Add(reader["nome"].ToString());
                    }
                    cbProduto.SelectedIndex = 0;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao carregar produtos: " + ex.Message);
                }
            }
        }

        private void CarregarMeses()
        {
            cbMes.Items.Add("Selecione um Mês");
            cbMes.Items.AddRange(new string[]
            {
                "Janeiro", "Fevereiro", "Março", "Abril", "Maio",
                "Junho", "Julho", "Agosto", "Setembro", "Outubro",
                "Novembro", "Dezembro"
            });
            cbMes.SelectedIndex = 0;
        }

        private void CarregarTransacoes()
        {
            DataTable transacoes = ObterTransacoes(null, null, null);
            dgvTransacoes.DataSource = transacoes;
        }

        private void BtnPesquisar_Click(object sender, EventArgs e)
        {
            string cliente = !string.IsNullOrEmpty(txtCliente.Text) ? txtCliente.Text : null;
            string produto = cbProduto.SelectedIndex > 0 ? cbProduto.SelectedItem.ToString() : null;
            string mesAno = cbMes.SelectedIndex > 0 && nudAno.Value > 0 ? $"{nudAno.Value}-{cbMes.SelectedIndex:00}" : null;

            DataTable transacoes = ObterTransacoes(cliente, produto, mesAno);
            dgvTransacoes.DataSource = transacoes;
        }

        private DataTable ObterTransacoes(string cliente, string produto, string mesAno)
        {
            DataTable table = new DataTable();
            string connectionString = "Server=localhost; Database=pap_cao; Uid=root; Pwd=;";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = @"SELECT 
                                        cliente.nome AS 'Cliente',
                                        produto.nome AS 'Produto',
                                        vendaproduto.dataVenda AS 'Data',
                                        vendaproduto.total AS 'Total (€)'
                                     FROM vendaproduto
                                     JOIN cliente ON vendaproduto.idCliente = cliente.idCliente
                                     JOIN produto ON vendaproduto.idProduto = produto.idProduto
                                     WHERE (@cliente IS NULL OR cliente.nome = @cliente)
                                     AND (@produto IS NULL OR produto.nome = @produto)
                                     AND (@mesAno IS NULL OR DATE_FORMAT(vendaproduto.dataVenda, '%Y-%m') = @mesAno)";
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@cliente", string.IsNullOrEmpty(cliente) ? (object)DBNull.Value : cliente);
                    cmd.Parameters.AddWithValue("@produto", string.IsNullOrEmpty(produto) ? (object)DBNull.Value : produto);
                    cmd.Parameters.AddWithValue("@mesAno", string.IsNullOrEmpty(mesAno) ? (object)DBNull.Value : mesAno);
                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    adapter.Fill(table);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao carregar transações: " + ex.Message);
                }
            }

            return table;
        }
    }
}