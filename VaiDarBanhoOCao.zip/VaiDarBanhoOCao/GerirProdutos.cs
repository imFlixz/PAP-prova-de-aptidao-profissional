﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace VaiDarBanhoOCao
{
    public partial class GerirProdutos : Form
    {
        public GerirProdutos()
        {
            InitializeComponent();
        }

        private void GerirProdutos_Load(object sender, EventArgs e)
        {
            CarregarProdutos();
            dgvProdutos.CellClick += dgvProdutos_CellClick; // Registra o evento CellClick
        }

        private void CarregarProdutos(string filtro = "")
        {
            string connectionString = "Server=localhost; Database=pap_cao; Uid=root; Pwd=;";
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT * FROM produto";

                    if (!string.IsNullOrEmpty(filtro))
                    {
                        query += " WHERE nome LIKE @filtro";
                    }

                    MySqlCommand cmd = new MySqlCommand(query, connection);

                    if (!string.IsNullOrEmpty(filtro))
                    {
                        cmd.Parameters.AddWithValue("@filtro", "%" + filtro + "%");
                    }

                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    dgvProdutos.DataSource = table;
                    dgvProdutos.Columns["idProduto"].Visible = false;

                    dgvProdutos.Columns["nome"].HeaderText = "Nome";
                    dgvProdutos.Columns["descricao"].HeaderText = "Descrição";
                    dgvProdutos.Columns["precoUnitario"].HeaderText = "Preço";
                    dgvProdutos.Columns["quantidadeEmStock"].HeaderText = "Stock";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao carregar produtos: " + ex.Message);
                }
            }
        }

        private void TxtPesquisar_Enter(object sender, EventArgs e)
        {
            if (txtPesquisar.Text == "Pesquisar por nome do produto...")
            {
                txtPesquisar.Text = "";
                txtPesquisar.ForeColor = Color.Black;
            }
        }

        private void TxtPesquisar_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtPesquisar.Text))
            {
                txtPesquisar.Text = "Pesquisar por nome do produto...";
                txtPesquisar.ForeColor = Color.Gray;
            }
        }

        private void TxtPesquisar_TextChanged(object sender, EventArgs e)
        {
            if (txtPesquisar.Text != "Pesquisar por nome do produto...")
            {
                CarregarProdutos(txtPesquisar.Text);
            }
        }

        private void TxtNome_Enter(object sender, EventArgs e)
        {
            if (txtNome.Text == "Nome do Produto")
            {
                txtNome.Text = "";
                txtNome.ForeColor = Color.Black;
            }
        }

        private void TxtNome_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNome.Text))
            {
                txtNome.Text = "Nome do Produto";
                txtNome.ForeColor = Color.Gray;
            }
        }

        private void TxtPreco_Enter(object sender, EventArgs e)
        {
            if (txtPreco.Text == "Preço")
            {
                txtPreco.Text = "";
                txtPreco.ForeColor = Color.Black;
            }
        }

        private void TxtPreco_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtPreco.Text))
            {
                txtPreco.Text = "Preço";
                txtPreco.ForeColor = Color.Gray;
            }
        }

        private void TxtQuantidade_Enter(object sender, EventArgs e)
        {
            if (txtQuantidade.Text == "Quantidade")
            {
                txtQuantidade.Text = "";
                txtQuantidade.ForeColor = Color.Black;
            }
        }

        private void TxtQuantidade_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtQuantidade.Text))
            {
                txtQuantidade.Text = "Quantidade";
                txtQuantidade.ForeColor = Color.Gray;
            }
        }

        private void TxtDescricao_Enter(object sender, EventArgs e)
        {
            if (txtDescricao.Text == "Descrição")
            {
                txtDescricao.Text = "";
                txtDescricao.ForeColor = Color.Black;
            }
        }

        private void TxtDescricao_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtDescricao.Text))
            {
                txtDescricao.Text = "Descrição";
                txtDescricao.ForeColor = Color.Gray;
            }
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            string nome = txtNome.Text.Trim();
            string descricao = txtDescricao.Text.Trim();
            decimal preco;
            int quantidade;

            if (string.IsNullOrWhiteSpace(nome) || string.IsNullOrWhiteSpace(descricao) ||
                !decimal.TryParse(txtPreco.Text, out preco) || !int.TryParse(txtQuantidade.Text, out quantidade))
            {
                MessageBox.Show("Por favor, preencha todos os campos corretamente.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string connectionString = "Server=localhost; Database=pap_cao; Uid=root; Pwd=;";
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "INSERT INTO produto (nome, descricao, precoUnitario, quantidadeEmStock) VALUES (@nome, @descricao, @preco, @quantidade)";
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@nome", nome);
                    cmd.Parameters.AddWithValue("@descricao", descricao);
                    cmd.Parameters.AddWithValue("@preco", preco);
                    cmd.Parameters.AddWithValue("@quantidade", quantidade);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Produto adicionado com sucesso.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    CarregarProdutos();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao adicionar produto: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (dgvProdutos.SelectedRows.Count == 0)
            {
                MessageBox.Show("Por favor, selecione um produto para editar.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int idProduto = Convert.ToInt32(dgvProdutos.SelectedRows[0].Cells["idProduto"].Value);
            string nome = txtNome.Text.Trim();
            string descricao = txtDescricao.Text.Trim();
            decimal preco;
            int quantidade;

            if (string.IsNullOrWhiteSpace(nome) || string.IsNullOrWhiteSpace(descricao) ||
                !decimal.TryParse(txtPreco.Text, out preco) || !int.TryParse(txtQuantidade.Text, out quantidade))
            {
                MessageBox.Show("Por favor, preencha todos os campos corretamente.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string connectionString = "Server=localhost; Database=pap_cao; Uid=root; Pwd=;";
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "UPDATE produto SET nome = @nome, descricao = @descricao, precoUnitario = @preco, quantidadeEmStock = @quantidade WHERE idProduto = @idProduto";
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@nome", nome);
                    cmd.Parameters.AddWithValue("@descricao", descricao);
                    cmd.Parameters.AddWithValue("@preco", preco);
                    cmd.Parameters.AddWithValue("@quantidade", quantidade);
                    cmd.Parameters.AddWithValue("@idProduto", idProduto);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Produto editado com sucesso.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    CarregarProdutos();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao editar produto: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnRemover_Click(object sender, EventArgs e)
        {
            if (dgvProdutos.SelectedRows.Count == 0)
            {
                MessageBox.Show("Por favor, selecione um produto para remover.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int idProduto = Convert.ToInt32(dgvProdutos.SelectedRows[0].Cells["idProduto"].Value);

            DialogResult result = MessageBox.Show("Tem a certeza de que deseja remover este produto?", "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.No)
            {
                return;
            }

            string connectionString = "Server=localhost; Database=pap_cao; Uid=root; Pwd=;";
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "DELETE FROM produto WHERE idProduto = @idProduto";
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@idProduto", idProduto);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Produto removido com sucesso.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    CarregarProdutos();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao remover produto: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void dgvProdutos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Certifique-se de que a linha clicada é válida
            {
                DataGridViewRow row = dgvProdutos.Rows[e.RowIndex];

                // Preenche as caixas de texto com os valores da linha selecionada
                txtNome.Text = row.Cells["nome"].Value.ToString();
                txtDescricao.Text = row.Cells["descricao"].Value.ToString();
                txtPreco.Text = row.Cells["precoUnitario"].Value.ToString();
                txtQuantidade.Text = row.Cells["quantidadeEmStock"].Value.ToString();

                // Ajusta as cores das caixas de texto
                txtNome.ForeColor = Color.Black;
                txtDescricao.ForeColor = Color.Black;
                txtPreco.ForeColor = Color.Black;
                txtQuantidade.ForeColor = Color.Black;
            }
        }
    }
}