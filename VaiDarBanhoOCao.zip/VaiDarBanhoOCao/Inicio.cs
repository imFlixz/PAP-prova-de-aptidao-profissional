﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace VaiDarBanhoOCao
{
    public partial class Inicio : Form
    {
        private TextBox txtPassword;
        private Button btnLogin;
        private PictureBox pictureBox;

        public Inicio()
        {
            InitializeComponent();
            InicializarControles();
        }

        private void InicializarControles()
        {
            this.Text = "Login";
            this.Size = new Size(500, 600);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 248, 255); // Tema de cor relaxante

            pictureBox = new PictureBox
            {
                Image = Image.FromFile("C:\\Users\\afons\\OneDrive\\Ambiente de Trabalho\\PAP\\transferir.png"), // Coloque o caminho da sua imagem aqui
                SizeMode = PictureBoxSizeMode.AutoSize,
                Location = new Point((this.ClientSize.Width - 250) / 2, 50), // Puxa a imagem um pouco para a esquerda
            };
            this.Controls.Add(pictureBox);

            Label lblPassword = new Label
            {
                Text = "Password:",
                Location = new Point((this.ClientSize.Width - 100) / 2, 350), // Centraliza o rótulo
                Size = new Size(100, 30),
                Font = new Font("Segoe UI", 12),
                ForeColor = Color.FromArgb(70, 130, 180)
            };
            this.Controls.Add(lblPassword);

            txtPassword = new TextBox
            {
                Location = new Point((this.ClientSize.Width - 200) / 2, 400), // Centraliza o campo de texto
                Size = new Size(200, 30),
                Font = new Font("Segoe UI", 12),
                UseSystemPasswordChar = true,
                BackColor = Color.White,
                ForeColor = Color.Black
            };
            this.Controls.Add(txtPassword);

            btnLogin = new Button
            {
                Text = "Login",
                Location = new Point((this.ClientSize.Width - 200) / 2, 450), // Centraliza o botão
                Size = new Size(200, 40),
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                BackColor = Color.FromArgb(100, 149, 237),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 }
            };
            btnLogin.Click += btnLogin_Click;
            btnLogin.Paint += (sender, e) =>
            {
                var btn = sender as Button;
                var rect = new Rectangle(0, 0, btn.Width, btn.Height);
                var path = new System.Drawing.Drawing2D.GraphicsPath();
                int radius = 20;
                path.AddArc(rect.X, rect.Y, radius, radius, 180, 90);
                path.AddArc(rect.X + rect.Width - radius, rect.Y, radius, radius, 270, 90);
                path.AddArc(rect.X + rect.Width - radius, rect.Y + rect.Height - radius, radius, radius, 0, 90);
                path.AddArc(rect.X, rect.Y + rect.Height - radius, radius, radius, 90, 90);
                btn.Region = new Region(path);
            };
            this.Controls.Add(btnLogin);

            // Captura o evento KeyDown para permitir login com Enter
            txtPassword.KeyDown += TxtPassword_KeyDown;
        }

        private void TxtPassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Chama o botão de login ao pressionar Enter
                btnLogin.PerformClick();
                e.Handled = true; // Evita comportamentos indesejados
                e.SuppressKeyPress = true; // Não permite que o som de "Enter" seja reproduzido
            }
        }

        private void Inicio_Load(object sender, EventArgs e)
        {
            // Define que os caracteres do TextBox serão exibidos como '*'
            txtPassword.UseSystemPasswordChar = true;

            // Define o foco inicial no campo txtPassword
            this.ActiveControl = txtPassword;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            // Password definida (substituir pela lógica certa)
            string passwordCorreta = "1234";

            // Verifica a password inserida
            if (txtPassword.Text == passwordCorreta)
            {
                // Abre o Menu
                Menu menuForm = new Menu();
                menuForm.Show();
                this.Hide(); // Esconde o formulário de login
            }
            else
            {
                // Mensagem de erro
                MessageBox.Show("Password incorreta. Tente novamente.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPassword.Clear(); // Limpa o campo de senha
                txtPassword.Focus(); // Retorna o foco ao campo de senha
            }
        }
    }
}