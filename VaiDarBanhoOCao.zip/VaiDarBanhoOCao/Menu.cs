﻿using MySql.Data.MySqlClient;
using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace VaiDarBanhoOCao
{
    public partial class Menu : Form
    {
        private Button btnAdicionarCliente;
        private Button btnConsultarCliente;
        private Button btnVerTipoServico;
        private Button btnVerServicosRealizados;
        private Button btnGerirProdutos;
        private Button btnRegistoTransacoes;
        private Button btnPesquisarTransacao; // Novo botão adicionado
        private ToolStripMenuItem itemSelecionado;
        private DataGridView dgvAniversarios;
        private Timer atualizarAniversarios;
        private MenuStrip menuStrip;

        public Menu()
        {
            InitializeComponent();
            InitializeMenu();
            InicializarAniversarios();
            CarregarAniversarios();
        }

        public static class ligarBD
        {
            public static MySqlConnection GetConnection()
            {
                string servidor = "localhost";
                string bancoDeDados = "pap_cao";
                string usuario = "root";
                string senha = "";
                string conexaoString = $"Server={servidor}; Database={bancoDeDados}; Uid={usuario}; Pwd={senha};";
                return new MySqlConnection(conexaoString);
            }
        }

        private void InitializeMenu()
        {
            menuStrip = new MenuStrip
            {
                Dock = DockStyle.Left,
                Width = 200,
                Font = new Font("Segoe UI", 12, FontStyle.Regular),
                BackColor = Color.FromArgb(45, 45, 48),
                ForeColor = Color.White,
                Padding = new Padding(10, 20, 10, 20)
            };

            var clientesMenuItem = new ToolStripMenuItem("Clientes");
            clientesMenuItem.Margin = new Padding(0, 10, 0, 10);
            clientesMenuItem.Click += (s, e) => MostrarBotaoSelecionado(clientesMenuItem);
            menuStrip.Items.Add(clientesMenuItem);

            var servicosMenuItem = new ToolStripMenuItem("Serviços");
            servicosMenuItem.Margin = new Padding(0, 10, 0, 10);
            servicosMenuItem.Click += (s, e) => MostrarBotaoSelecionado(servicosMenuItem);
            menuStrip.Items.Add(servicosMenuItem);

            var produtosMenuItem = new ToolStripMenuItem("Produtos");
            produtosMenuItem.Margin = new Padding(0, 10, 0, 10);
            produtosMenuItem.Click += (s, e) => MostrarBotaoSelecionado(produtosMenuItem);
            menuStrip.Items.Add(produtosMenuItem);

            this.Controls.Add(menuStrip);

            btnAdicionarCliente = CriarBotao("Adicionar Cliente");
            btnAdicionarCliente.Click += btnAdicionarCliente_Click;

            btnConsultarCliente = CriarBotao("Consultar Cliente");
            btnConsultarCliente.Click += btnConsultarCliente_Click;

            btnVerTipoServico = CriarBotao("Ver Tipo Serviço");
            btnVerTipoServico.Click += btnVerTipoServico_Click;

            btnVerServicosRealizados = CriarBotao("Ver Serviços Realizados");
            btnVerServicosRealizados.Click += btnVerServicosRealizados_Click;

            btnGerirProdutos = CriarBotao("Gerir Produtos");
            btnGerirProdutos.Click += btnGerirProdutos_Click;

            btnRegistoTransacoes = CriarBotao("Registo de Transações");
            btnRegistoTransacoes.Click += btnRegistoTransacoes_Click;

            btnPesquisarTransacao = CriarBotao("Pesquisar Transação"); // Novo botão criado
            btnPesquisarTransacao.Click += btnPesquisarTransacao_Click;

            this.Controls.Add(btnAdicionarCliente);
            this.Controls.Add(btnConsultarCliente);
            this.Controls.Add(btnVerTipoServico);
            this.Controls.Add(btnVerServicosRealizados);
            this.Controls.Add(btnGerirProdutos);
            this.Controls.Add(btnRegistoTransacoes);
            this.Controls.Add(btnPesquisarTransacao); // Adiciona o botão ao formulário
        }

        private void InicializarAniversarios()
        {
            dgvAniversarios = new DataGridView
            {
                Location = new Point(180, 20),
                Size = new Size(600, 150),
                ReadOnly = true,
                AllowUserToAddRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.FromArgb(45, 45, 48),
                    ForeColor = Color.White,
                    Font = new Font("Segoe UI", 10, FontStyle.Bold)
                },
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.White,
                    ForeColor = Color.Black,
                    Font = new Font("Segoe UI", 10, FontStyle.Regular),
                    SelectionBackColor = Color.FromArgb(0, 122, 204),
                    SelectionForeColor = Color.White
                },
                EnableHeadersVisualStyles = false,
                ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single,
                CellBorderStyle = DataGridViewCellBorderStyle.Single,
                GridColor = Color.FromArgb(230, 230, 230),
                AllowUserToResizeColumns = true
            };

            dgvAniversarios.Columns.Add(new DataGridViewTextBoxColumn { Name = "Dia", HeaderText = "Dia", Width = 100 });
            dgvAniversarios.Columns.Add(new DataGridViewTextBoxColumn { Name = "NomeAnimal", HeaderText = "Nome do Cão", Width = 150 });
            dgvAniversarios.Columns.Add(new DataGridViewTextBoxColumn { Name = "Cliente", HeaderText = "Nome do Cliente", Width = 150 });
            dgvAniversarios.Columns.Add(new DataGridViewTextBoxColumn { Name = "Telefone", HeaderText = "Telefone", Width = 150 });

            this.Controls.Add(dgvAniversarios);

            atualizarAniversarios = new Timer { Interval = 60000 };
            atualizarAniversarios.Tick += (s, e) => CarregarAniversarios();
            atualizarAniversarios.Start();
        }

        private void CarregarAniversarios()
        {
            try
            {
                using (MySqlConnection conexao = ligarBD.GetConnection())
                {
                    conexao.Open();
                    string query = @"SELECT DATE_FORMAT(a.aniversario, '%d/%m/%Y') AS Dia, 
                                            a.nomeAnimal AS NomeAnimal,
                                            c.nome AS Cliente, 
                                            c.telefone AS Telefone 
                                    FROM Cliente c
                                    JOIN Animal a ON c.idCliente = a.idCliente
                                    WHERE a.aniversario BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 4 DAY) 
                                    ORDER BY a.aniversario";
                    MySqlCommand cmd = new MySqlCommand(query, conexao);
                    MySqlDataReader reader = cmd.ExecuteReader();

                    dgvAniversarios.Rows.Clear();

                    while (reader.Read())
                    {
                        dgvAniversarios.Rows.Add(reader["Dia"], reader["NomeAnimal"], reader["Cliente"], reader["Telefone"]);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar aniversários: " + ex.Message);
            }
        }

        private Button CriarBotao(string texto)
        {
            Button button = new Button
            {
                Text = texto,
                Size = new Size(250, 60),
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                BackColor = Color.FromArgb(100, 149, 237),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Visible = false,
                Margin = new Padding(10),
                FlatAppearance = { BorderSize = 0 }
            };

            button.Paint += (sender, e) =>
            {
                var btn = sender as Button;
                var rect = new Rectangle(0, 0, btn.Width, btn.Height);
                var path = new System.Drawing.Drawing2D.GraphicsPath();
                int radius = 10;
                path.AddArc(rect.X, rect.Y, radius, radius, 180, 90);
                path.AddArc(rect.X + rect.Width - radius, rect.Y, radius, radius, 270, 90);
                path.AddArc(rect.X + rect.Width - radius, rect.Y + rect.Height - radius, radius, radius, 0, 90);
                path.AddArc(rect.X, rect.Y + rect.Height - radius, radius, radius, 90, 90);
                btn.Region = new Region(path);
            };

            return button;
        }

        private void MostrarBotaoSelecionado(ToolStripMenuItem menuItem)
        {
            if (itemSelecionado != null)
            {
                itemSelecionado.BackColor = Color.FromArgb(45, 45, 48);
            }

            menuItem.BackColor = Color.FromArgb(100, 149, 237);
            itemSelecionado = menuItem;

            // Oculta todos os botões antes de mostrar os necessários
            btnAdicionarCliente.Visible = false;
            btnConsultarCliente.Visible = false;
            btnVerTipoServico.Visible = false;
            btnVerServicosRealizados.Visible = false;
            btnGerirProdutos.Visible = false;
            btnRegistoTransacoes.Visible = false;
            btnPesquisarTransacao.Visible = false;

            if (menuItem.Text == "Clientes")
            {
                MostrarBotoesLadoALado(btnAdicionarCliente, btnConsultarCliente);
            }
            else if (menuItem.Text == "Serviços")
            {
                MostrarBotoesLadoALado(btnVerTipoServico, btnVerServicosRealizados);
            }
            else if (menuItem.Text == "Produtos")
            {
                MostrarBotoesProdutos();
            }
        }

        private void MostrarBotoesProdutos()
        {
            int margemHorizontal = 20; // Distância horizontal entre os botões
            int margemVertical = 20;   // Distância vertical entre os botões

            int larguraMenuStrip = menuStrip.Width;
            int areaUtilX = this.ClientSize.Width - larguraMenuStrip;
            int posicaoX = larguraMenuStrip + (areaUtilX - (btnGerirProdutos.Width * 2 + margemHorizontal)) / 2; // Centraliza os dois botões lado a lado no eixo X
            int posicaoY = (this.ClientSize.Height - (btnGerirProdutos.Height * 2 + margemVertical)) / 2; // Centraliza o conjunto no eixo Y

            // Posiciona "Gerir Produtos" e "Registo de Transações" lado a lado
            btnGerirProdutos.Location = new Point(posicaoX, posicaoY);
            btnGerirProdutos.Visible = true;

            btnRegistoTransacoes.Location = new Point(posicaoX + btnGerirProdutos.Width + margemHorizontal, posicaoY);
            btnRegistoTransacoes.Visible = true;

            // Posiciona "Pesquisar Transação" abaixo, centralizado
            btnPesquisarTransacao.Location = new Point(larguraMenuStrip + (areaUtilX - btnPesquisarTransacao.Width) / 2, posicaoY + btnGerirProdutos.Height + margemVertical);
            btnPesquisarTransacao.Visible = true;
        }

        private void MostrarBotoesLadoALado(params Button[] botoes)
        {
            int margemHorizontal = 20;
            int larguraMenuStrip = menuStrip.Width;
            int areaUtil = this.ClientSize.Width - larguraMenuStrip;
            int totalLarguraBotoes = botoes.Sum(botao => botao.Width) + (botoes.Length - 1) * margemHorizontal;
            int posicaoX = larguraMenuStrip + (areaUtil - totalLarguraBotoes) / 2;

            foreach (var botao in botoes)
            {
                botao.Location = new Point(posicaoX, (this.ClientSize.Height - botao.Height) / 2);
                botao.Visible = true;
                posicaoX += botao.Width + margemHorizontal;
            }
        }

        private void btnAdicionarCliente_Click(object sender, EventArgs e)
        {
            AdicionarCliente adicionarClienteForm = new AdicionarCliente();
            adicionarClienteForm.Show();
        }

        private void btnVerTipoServico_Click(object sender, EventArgs e)
        {
            VerTipoServico verTipoServicoForm = new VerTipoServico();
            verTipoServicoForm.Show();
        }

        private void btnConsultarCliente_Click(object sender, EventArgs e)
        {
            ConsultarCliente consultarClienteForm = new ConsultarCliente();
            consultarClienteForm.Show();
        }

        private void btnVerServicosRealizados_Click(object sender, EventArgs e)
        {
            VerServicosRealizados consultarServicoForm = new VerServicosRealizados();
            consultarServicoForm.Show();
        }

        private void btnGerirProdutos_Click(object sender, EventArgs e)
        {
            GerirProdutos gerirProdutosForm = new GerirProdutos();
            gerirProdutosForm.Show();
        }

        private void btnRegistoTransacoes_Click(object sender, EventArgs e)
        {
            RegistoTransacoes registoTransacoesForm = new RegistoTransacoes();
            registoTransacoesForm.Show();
        }

        private void btnPesquisarTransacao_Click(object sender, EventArgs e)
        {
            PesquisarTransacao pesquisarTransacaoForm = new PesquisarTransacao();
            pesquisarTransacaoForm.Show();
        }

        private void Menu_Load(object sender, EventArgs e)
        {

        }
    }
}