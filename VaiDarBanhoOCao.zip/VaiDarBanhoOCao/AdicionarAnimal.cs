﻿using MySql.Data.MySqlClient;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace VaiDarBanhoOCao
{
    public partial class AdicionarAnimal : Form
    {
        private TextBox txtNome;
        private TextBox txtRaca;
        private DateTimePicker dtpNascimento;
        private TextBox txtObservacoes;
        private Button btnSalvar;
        private int idCliente;

        public AdicionarAnimal(int idClienteSelecionado)
        {
            InitializeComponent();
            idCliente = idClienteSelecionado;
            CriarComponentes();
        }

        public static class ligarBD
        {
            public static MySqlConnection GetConnection()
            {
                string servidor = "localhost";
                string bancoDeDados = "pap_cao";
                string usuario = "root";
                string senha = "";
                string conexaoString = $"Server={servidor}; Database={bancoDeDados}; Uid={usuario}; Pwd={senha};";
                return new MySqlConnection(conexaoString);
            }
        }

        private void AdicionarAnimal_Load(object sender, EventArgs e) {}

        private void CriarComponentes()
        {
            this.Text = "Adicionar Animal";
            this.Size = new Size(450, 400); // Aumentando o tamanho do formulário
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 248, 255); // Tema de cor relaxante

            Label lblNome = new Label
            {
                Text = "Nome:",
                Location = new Point(30, 30),
                Size = new Size(120, 20),
                Font = new Font("Segoe UI", 11, FontStyle.Regular),
                ForeColor = Color.FromArgb(70, 130, 180)
            };
            this.Controls.Add(lblNome);

            txtNome = new TextBox
            {
                Location = new Point(200, 30), // Ajustando a posição para alinhamento
                Size = new Size(200, 25),
                Font = new Font("Segoe UI", 11, FontStyle.Regular)
            };
            this.Controls.Add(txtNome);

            Label lblRaca = new Label
            {
                Text = "Raça:",
                Location = new Point(30, 70),
                Size = new Size(120, 20),
                Font = new Font("Segoe UI", 11, FontStyle.Regular),
                ForeColor = Color.FromArgb(70, 130, 180)
            };
            this.Controls.Add(lblRaca);

            txtRaca = new TextBox
            {
                Location = new Point(200, 70), // Ajustando a posição para alinhamento
                Size = new Size(200, 25),
                Font = new Font("Segoe UI", 11, FontStyle.Regular)
            };
            this.Controls.Add(txtRaca);

            Label lblNascimento = new Label
            {
                Text = "Data de Nascimento:",
                Location = new Point(30, 110),
                Size = new Size(160, 20), // Ajuste do tamanho para melhor exibição
                Font = new Font("Segoe UI", 11, FontStyle.Regular),
                ForeColor = Color.FromArgb(70, 130, 180)
            };
            this.Controls.Add(lblNascimento);

            dtpNascimento = new DateTimePicker
            {
                Location = new Point(200, 110), // Ajustando a posição para alinhamento
                Size = new Size(200, 25),
                Font = new Font("Segoe UI", 11, FontStyle.Regular)
            };
            this.Controls.Add(dtpNascimento);

            Label lblObservacoes = new Label
            {
                Text = "Observações:",
                Location = new Point(30, 150),
                Size = new Size(120, 20),
                Font = new Font("Segoe UI", 11, FontStyle.Regular),
                ForeColor = Color.FromArgb(70, 130, 180)
            };
            this.Controls.Add(lblObservacoes);

            txtObservacoes = new TextBox
            {
                Location = new Point(200, 150), // Ajustando a posição para alinhamento
                Size = new Size(200, 60),
                Multiline = true,
                Font = new Font("Segoe UI", 11, FontStyle.Regular)
            };
            this.Controls.Add(txtObservacoes);

            btnSalvar = new Button
            {
                Text = "Salvar",
                Location = new Point(150, 260), // Ajuste da posição
                Size = new Size(100, 40),
                BackColor = Color.FromArgb(100, 149, 237),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 12, FontStyle.Bold)
            };
            btnSalvar.FlatAppearance.BorderSize = 0;
            btnSalvar.Paint += (sender, e) =>
            {
                var btn = sender as Button;
                var rect = new Rectangle(0, 0, btn.Width, btn.Height);
                var path = new System.Drawing.Drawing2D.GraphicsPath();
                int radius = 20;
                path.AddArc(rect.X, rect.Y, radius, radius, 180, 90);
                path.AddArc(rect.X + rect.Width - radius, rect.Y, radius, radius, 270, 90);
                path.AddArc(rect.X + rect.Width - radius, rect.Y + rect.Height - radius, radius, radius, 0, 90);
                path.AddArc(rect.X, rect.Y + rect.Height - radius, radius, radius, 90, 90);
                btn.Region = new Region(path);
            };
            btnSalvar.Click += BtnSalvar_Click;
            this.Controls.Add(btnSalvar);
        }

        private void BtnSalvar_Click(object sender, EventArgs e)
        {
            string nome = txtNome.Text;
            string raca = txtRaca.Text;
            DateTime nascimento = dtpNascimento.Value;
            string observacoes = txtObservacoes.Text;

            if (string.IsNullOrWhiteSpace(nome) || string.IsNullOrWhiteSpace(raca))
            {
                MessageBox.Show("Preencha todos os campos obrigatórios.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            LigarBD(nome, raca, nascimento, observacoes);
        }

        private void LigarBD(string nome, string raca, DateTime nascimento, string observacoes)
        {
            try
            {
                using (MySqlConnection conexao = ligarBD.GetConnection())
                {
                    conexao.Open();

                    // Inserir o animal com o idCliente correto
                    string query = "INSERT INTO animal (NomeAnimal, raca, aniversario, Observacoes, ativo, idCliente) " +
                                   "VALUES (@Nome, @Raca, @DataNascimento, @Observacoes, 1, @IdCliente)";
                    using (MySqlCommand cmd = new MySqlCommand(query, conexao))
                    {
                        cmd.Parameters.AddWithValue("@Nome", nome);
                        cmd.Parameters.AddWithValue("@Raca", raca);
                        cmd.Parameters.AddWithValue("@DataNascimento", nascimento);
                        cmd.Parameters.AddWithValue("@Observacoes", observacoes);
                        cmd.Parameters.AddWithValue("@IdCliente", idCliente);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Animal adicionado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao adicionar animal: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}