﻿namespace VaiDarBanhoOCao
{
    partial class RegistoTransacoes
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.ComboBox cbProdutos;
        private System.Windows.Forms.TextBox txtClientes;
        private System.Windows.Forms.TextBox txtQuantidade;
        private System.Windows.Forms.DateTimePicker dtpData;
        private System.Windows.Forms.Button btnAdicionarTransacao;
        private System.Windows.Forms.DataGridView dgvTransacoes;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegistoTransacoes));
            this.cbProdutos = new System.Windows.Forms.ComboBox();
            this.txtClientes = new System.Windows.Forms.TextBox();
            this.txtQuantidade = new System.Windows.Forms.TextBox();
            this.dtpData = new System.Windows.Forms.DateTimePicker();
            this.btnAdicionarTransacao = new System.Windows.Forms.Button();
            this.dgvTransacoes = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTransacoes)).BeginInit();
            this.SuspendLayout();
            // 
            // cbProdutos
            // 
            this.cbProdutos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbProdutos.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cbProdutos.FormattingEnabled = true;
            this.cbProdutos.Location = new System.Drawing.Point(50, 50);
            this.cbProdutos.Name = "cbProdutos";
            this.cbProdutos.Size = new System.Drawing.Size(200, 29);
            this.cbProdutos.TabIndex = 0;
            // 
            // txtClientes
            // 
            this.txtClientes.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtClientes.Location = new System.Drawing.Point(50, 100);
            this.txtClientes.Name = "txtClientes";
            this.txtClientes.Size = new System.Drawing.Size(200, 29);
            this.txtClientes.TabIndex = 1;
            // 
            // txtQuantidade
            // 
            this.txtQuantidade.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txtQuantidade.ForeColor = System.Drawing.Color.Gray;
            this.txtQuantidade.Location = new System.Drawing.Point(270, 50);
            this.txtQuantidade.Name = "txtQuantidade";
            this.txtQuantidade.Size = new System.Drawing.Size(100, 29);
            this.txtQuantidade.TabIndex = 2;
            this.txtQuantidade.Text = "Quantidade";
            this.txtQuantidade.Enter += new System.EventHandler(this.TxtQuantidade_Enter);
            this.txtQuantidade.Leave += new System.EventHandler(this.TxtQuantidade_Leave);
            // 
            // dtpData
            // 
            this.dtpData.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.dtpData.Location = new System.Drawing.Point(390, 50);
            this.dtpData.Name = "dtpData";
            this.dtpData.Size = new System.Drawing.Size(250, 29);
            this.dtpData.TabIndex = 3;
            // 
            // btnAdicionarTransacao
            // 
            this.btnAdicionarTransacao.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnAdicionarTransacao.Location = new System.Drawing.Point(660, 50);
            this.btnAdicionarTransacao.Name = "btnAdicionarTransacao";
            this.btnAdicionarTransacao.Size = new System.Drawing.Size(150, 40);
            this.btnAdicionarTransacao.TabIndex = 4;
            this.btnAdicionarTransacao.Text = "Adicionar";
            this.btnAdicionarTransacao.UseVisualStyleBackColor = true;
            this.btnAdicionarTransacao.Click += new System.EventHandler(this.btnAdicionarTransacao_Click);
            // 
            // dgvTransacoes
            // 
            this.dgvTransacoes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTransacoes.Location = new System.Drawing.Point(50, 170);
            this.dgvTransacoes.Name = "dgvTransacoes";
            this.dgvTransacoes.Size = new System.Drawing.Size(760, 300);
            this.dgvTransacoes.TabIndex = 5;
            // 
            // RegistoTransacoes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(864, 500);
            this.Controls.Add(this.dgvTransacoes);
            this.Controls.Add(this.btnAdicionarTransacao);
            this.Controls.Add(this.dtpData);
            this.Controls.Add(this.txtQuantidade);
            this.Controls.Add(this.txtClientes);
            this.Controls.Add(this.cbProdutos);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "RegistoTransacoes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registo de Transações";
            this.Load += new System.EventHandler(this.RegistoTransacoes_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTransacoes)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}