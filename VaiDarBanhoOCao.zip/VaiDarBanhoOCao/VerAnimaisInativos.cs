﻿using MySql.Data.MySqlClient;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace VaiDarBanhoOCao
{
    public partial class VerAnimaisInativos : Form
    {
        private DataGridView dgvAnimaisInativos;
        private Button btnReativarAnimal;
        public event Action AnimalReativado; // Evento para notificar reativação de animal

        public VerAnimaisInativos()
        {
            InitializeComponent();
            InicializarControles();
            CarregarAnimaisInativos();
        }

        public static class ligarBD
        {
            public static MySqlConnection GetConnection()
            {
                return new MySqlConnection("Server=localhost; Database=pap_cao; Uid=root; Pwd=;");
            }
        }

        private void InicializarControles()
        {
            this.Text = "Animais Inativos";
            this.Size = new Size(800, 600);
            this.BackColor = Color.FromArgb(240, 240, 240);

            Panel panelPrincipal = CriarPanel();
            this.Controls.Add(panelPrincipal);

            dgvAnimaisInativos = CriarDataGridView(new Point(20, 20), new Size(740, 440), new string[] { "idAnimal", "NomeAnimal", "Raca", "Observacoes", "NomeDono" });
            panelPrincipal.Controls.Add(dgvAnimaisInativos);

            btnReativarAnimal = CriarButton("Reativar Animal", new Point(20, 480), BtnReativarAnimal_Click, false);
            panelPrincipal.Controls.Add(btnReativarAnimal);
        }

        private Panel CriarPanel()
        {
            return new Panel
            {
                Size = new Size(760, 540),
                Location = new Point(20, 20),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.White
            };
        }

        private DataGridView CriarDataGridView(Point location, Size size, string[] columnNames)
        {
            var dgv = new DataGridView
            {
                Location = location,
                Size = size,
                AllowUserToAddRows = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.FromArgb(45, 45, 48),
                    ForeColor = Color.White,
                    Font = new Font("Segoe UI", 10, FontStyle.Bold)
                },
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.White,
                    ForeColor = Color.Black,
                    Font = new Font("Segoe UI", 10, FontStyle.Regular),
                    SelectionBackColor = Color.FromArgb(0, 122, 204),
                    SelectionForeColor = Color.White
                },
                EnableHeadersVisualStyles = false,
                ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single,
                CellBorderStyle = DataGridViewCellBorderStyle.Single,
                GridColor = Color.FromArgb(230, 230, 230)
            };

            foreach (var columnName in columnNames)
            {
                dgv.Columns.Add(columnName, columnName);
                if (columnName == "idAnimal") dgv.Columns[columnName].Visible = false;
            }

            dgv.SelectionChanged += DgvAnimaisInativos_SelectionChanged;

            return dgv;
        }

        private Button CriarButton(string text, Point location, EventHandler clickEvent, bool enabled = true)
        {
            var btn = new Button
            {
                Text = text,
                Location = location,
                Size = new Size(150, 40),
                Enabled = enabled,
                BackColor = Color.FromArgb(100, 149, 237),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 12, FontStyle.Bold)
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.Click += clickEvent;
            btn.Paint += (sender, e) =>
            {
                var button = sender as Button;
                var rect = new Rectangle(0, 0, button.Width, button.Height);
                var path = new System.Drawing.Drawing2D.GraphicsPath();
                int radius = 10;
                path.AddArc(rect.X, rect.Y, radius, radius, 180, 90);
                path.AddArc(rect.X + rect.Width - radius, rect.Y, radius, radius, 270, 90);
                path.AddArc(rect.X + rect.Width - radius, rect.Y + rect.Height - radius, radius, radius, 0, 90);
                path.AddArc(rect.X, rect.Y + rect.Height - radius, radius, radius, 90, 90);
                button.Region = new Region(path);
            };
            return btn;
        }

        private void CarregarAnimaisInativos()
        {
            using (var conexao = ligarBD.GetConnection())
            {
                conexao.Open();
                string query = @"
                    SELECT Animal.idAnimal, Animal.NomeAnimal, Animal.Raca, Animal.Observacoes, Cliente.Nome AS NomeDono 
                    FROM Animal
                    INNER JOIN Cliente ON Animal.idCliente = Cliente.idCliente
                    WHERE Animal.ativo = 0";
                using (var cmd = new MySqlCommand(query, conexao))
                {
                    using (var reader = cmd.ExecuteReader())
                    {
                        dgvAnimaisInativos.Rows.Clear();
                        while (reader.Read())
                        {
                            dgvAnimaisInativos.Rows.Add(reader["idAnimal"], reader["NomeAnimal"], reader["Raca"], reader["Observacoes"], reader["NomeDono"]);
                        }
                    }
                }
            }
        }

        private void DgvAnimaisInativos_SelectionChanged(object sender, EventArgs e)
        {
            btnReativarAnimal.Enabled = dgvAnimaisInativos.SelectedRows.Count > 0;
        }

        private void BtnReativarAnimal_Click(object sender, EventArgs e)
        {
            if (dgvAnimaisInativos.SelectedRows.Count == 0)
            {
                MessageBox.Show("Selecione um animal antes de reativar.");
                return;
            }

            var row = dgvAnimaisInativos.SelectedRows[0];
            int idAnimalSelecionado = Convert.ToInt32(row.Cells["idAnimal"].Value);

            using (var conexao = ligarBD.GetConnection())
            {
                conexao.Open();
                string query = "UPDATE Animal SET ativo = 1 WHERE idAnimal = @idAnimal";
                using (var cmd = new MySqlCommand(query, conexao))
                {
                    cmd.Parameters.AddWithValue("@idAnimal", idAnimalSelecionado);
                    cmd.ExecuteNonQuery();
                }
            }

            MessageBox.Show("Animal reativado com sucesso.");
            CarregarAnimaisInativos();
            AnimalReativado?.Invoke(); // Notificar que um animal foi reativado
        }
    }
}