﻿    namespace VaiDarBanhoOCao
    {
        partial class VerServicosRealizados
        {
            /// <summary>
            /// Required designer variable.
            /// </summary>
            private System.ComponentModel.IContainer components = null;

            /// <summary>
            /// Clean up any resources being used.
            /// </summary>
            /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
            protected override void Dispose(bool disposing)
            {
                if (disposing && (components != null))
                {
                    components.Dispose();
                }
                base.Dispose(disposing);
            }

            #region Windows Form Designer generated code

            /// <summary>
            /// Required method for Designer support - do not modify
            /// the contents of this method with the code editor.
            /// </summary>
            private void InitializeComponent()
            {
                System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VerServicosRealizados));
                this.cbServico = new System.Windows.Forms.ComboBox();
                this.dtpData = new System.Windows.Forms.DateTimePicker();
                this.cbMes = new System.Windows.Forms.ComboBox();
                this.nudAno = new System.Windows.Forms.NumericUpDown();
                this.btnPesquisar = new System.Windows.Forms.Button();
                this.dgvServicosRealizados = new System.Windows.Forms.DataGridView();
                ((System.ComponentModel.ISupportInitialize)(this.nudAno)).BeginInit();
                ((System.ComponentModel.ISupportInitialize)(this.dgvServicosRealizados)).BeginInit();
                this.SuspendLayout();
                // 
                // cbServico
                // 
                this.cbServico.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
                this.cbServico.Font = new System.Drawing.Font("Segoe UI", 12F);
                this.cbServico.FormattingEnabled = true;
                this.cbServico.Location = new System.Drawing.Point(50, 50);
                this.cbServico.Name = "cbServico";
                this.cbServico.Size = new System.Drawing.Size(200, 29);
                this.cbServico.TabIndex = 0;
                // 
                // dtpData
                // 
                this.dtpData.Checked = false;
                this.dtpData.Font = new System.Drawing.Font("Segoe UI", 12F);
                this.dtpData.Location = new System.Drawing.Point(270, 50);
                this.dtpData.Name = "dtpData";
                this.dtpData.Size = new System.Drawing.Size(200, 29);
                this.dtpData.TabIndex = 1;
                // 
                // cbMes
                // 
                this.cbMes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
                this.cbMes.Font = new System.Drawing.Font("Segoe UI", 12F);
                this.cbMes.FormattingEnabled = true;
                this.cbMes.Location = new System.Drawing.Point(490, 50);
                this.cbMes.Name = "cbMes";
                this.cbMes.Size = new System.Drawing.Size(120, 29);
                this.cbMes.TabIndex = 2;
                // 
                // nudAno
                // 
                this.nudAno.Font = new System.Drawing.Font("Segoe UI", 12F);
                this.nudAno.Location = new System.Drawing.Point(620, 50);
                this.nudAno.Maximum = new decimal(new int[] {
                2100,
                0,
                0,
                0});
                this.nudAno.Minimum = new decimal(new int[] {
                2000,
                0,
                0,
                0});
                this.nudAno.Name = "nudAno";
                this.nudAno.Size = new System.Drawing.Size(80, 29);
                this.nudAno.TabIndex = 3;
                this.nudAno.Value = new decimal(new int[] {
                2025,
                0,
                0,
                0});

                // 
                // btnPesquisar
                // 
                this.btnPesquisar.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
                this.btnPesquisar.Location = new System.Drawing.Point(920, 50);
                this.btnPesquisar.Name = "btnPesquisar";
                this.btnPesquisar.Size = new System.Drawing.Size(120, 40);
                this.btnPesquisar.TabIndex = 4;
                this.btnPesquisar.Text = "Pesquisar";
                this.btnPesquisar.UseVisualStyleBackColor = true;
                this.btnPesquisar.Click += new System.EventHandler(this.btnPesquisar_Click);
                // 
                // dgvServicosRealizados
                // 
                this.dgvServicosRealizados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
                this.dgvServicosRealizados.Location = new System.Drawing.Point(50, 120);
                this.dgvServicosRealizados.Name = "dgvServicosRealizados";
                this.dgvServicosRealizados.Size = new System.Drawing.Size(990, 300);
                this.dgvServicosRealizados.TabIndex = 5;
                // 
                // VerServicosRealizados
                // 
                this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
                this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
                this.ClientSize = new System.Drawing.Size(1100, 450);
                this.Controls.Add(this.dgvServicosRealizados);
                this.Controls.Add(this.btnPesquisar);
                this.Controls.Add(this.nudAno);
                this.Controls.Add(this.cbMes);
                this.Controls.Add(this.dtpData);
                this.Controls.Add(this.cbServico);
                this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
                this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
                this.MaximizeBox = false;
                this.Name = "VerServicosRealizados";
                this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
                this.Text = "Ver Serviços Realizados";
                this.Load += new System.EventHandler(this.VerServicosRealizados_Load);
                ((System.ComponentModel.ISupportInitialize)(this.nudAno)).EndInit();
                ((System.ComponentModel.ISupportInitialize)(this.dgvServicosRealizados)).EndInit();
                this.ResumeLayout(false);

            }

            #endregion

            private System.Windows.Forms.ComboBox cbServico;
            private System.Windows.Forms.DateTimePicker dtpData;
            private System.Windows.Forms.ComboBox cbMes;
            private System.Windows.Forms.NumericUpDown nudAno;
            private System.Windows.Forms.Button btnPesquisar;
            private System.Windows.Forms.DataGridView dgvServicosRealizados;
        }
    }