﻿namespace VaiDarBanhoOCao
{
    partial class ConsultarCliente
    {
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ConsultarCliente));
            this.lblClienteSelecionado = new System.Windows.Forms.Label();
            this.btnAdicionarServico = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblClienteSelecionado
            // 
            this.lblClienteSelecionado.Location = new System.Drawing.Point(0, 0);
            this.lblClienteSelecionado.Name = "lblClienteSelecionado";
            this.lblClienteSelecionado.Size = new System.Drawing.Size(100, 23);
            this.lblClienteSelecionado.TabIndex = 0;
            // 
            // btnAdicionarServico
            // 
            this.btnAdicionarServico.Location = new System.Drawing.Point(0, 0);
            this.btnAdicionarServico.Name = "btnAdicionarServico";
            this.btnAdicionarServico.Size = new System.Drawing.Size(75, 23);
            this.btnAdicionarServico.TabIndex = 1;
            // 
            // ConsultarCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.lblClienteSelecionado);
            this.Controls.Add(this.btnAdicionarServico);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "ConsultarCliente";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Consultar Cliente";
            this.Load += new System.EventHandler(this.ConsultarCliente_Load);
            this.ResumeLayout(false);

        }
    }
}