﻿using MySql.Data.MySqlClient;
using System;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace VaiDarBanhoOCao
{
    public partial class FormEditarCliente : Form
    {
        private int idCliente;
        private TextBox txtNome;
        private TextBox txtMorada;
        private TextBox txtNIF;
        private TextBox txtTelefone;
        private TextBox txtEmail;
        private Button btnSalvar;

        public FormEditarCliente(int idCliente)
        {
            InitializeComponent();
            this.idCliente = idCliente;
            this.Text = "Editar Cliente";
            this.Size = new Size(400, 400);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 248, 255); // Tema de cor relaxante
            InicializarControles();
            CarregarDadosCliente();
        }

        private void InicializarControles()
        {
            AddLabel("Nome:", new Point(30, 30));
            txtNome = AddTextBox(new Point(160, 30));

            AddLabel("Morada:", new Point(30, 70));
            txtMorada = AddTextBox(new Point(160, 70));

            AddLabel("NIF:", new Point(30, 110));
            txtNIF = AddTextBox(new Point(160, 110));

            AddLabel("Telefone:", new Point(30, 150));
            txtTelefone = AddTextBox(new Point(160, 150));

            AddLabel("Email:", new Point(30, 190));
            txtEmail = AddTextBox(new Point(160, 190));

            btnSalvar = AddButton("Salvar", new Point(140, 250), BtnSalvar_Click);
        }

        private Label AddLabel(string text, Point location)
        {
            var label = new Label
            {
                Text = text,
                Location = location,
                Size = new Size(120, 20),
                Font = new Font("Segoe UI", 11, FontStyle.Regular),
                ForeColor = Color.FromArgb(70, 130, 180)
            };
            this.Controls.Add(label);
            return label;
        }

        private TextBox AddTextBox(Point location)
        {
            var textBox = new TextBox
            {
                Location = location,
                Size = new Size(180, 25),
                Font = new Font("Segoe UI", 10, FontStyle.Regular),
                BackColor = Color.White,
                ForeColor = Color.Black
            };
            this.Controls.Add(textBox);
            return textBox;
        }

        private Button AddButton(string text, Point location, EventHandler clickEvent)
        {
            var button = new Button
            {
                Text = text,
                Location = location,
                Size = new Size(120, 40),
                BackColor = Color.FromArgb(100, 149, 237),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 12, FontStyle.Bold)
            };
            button.FlatAppearance.BorderSize = 0;
            button.Click += clickEvent;
            button.Paint += (sender, e) =>
            {
                var btn = sender as Button;
                var rect = new Rectangle(0, 0, btn.Width, btn.Height);
                var path = new System.Drawing.Drawing2D.GraphicsPath();
                int radius = 20;
                path.AddArc(rect.X, rect.Y, radius, radius, 180, 90);
                path.AddArc(rect.X + rect.Width - radius, rect.Y, radius, radius, 270, 90);
                path.AddArc(rect.X + rect.Width - radius, rect.Y + rect.Height - radius, radius, radius, 0, 90);
                path.AddArc(rect.X, rect.Y + rect.Height - radius, radius, radius, 90, 90);
                btn.Region = new Region(path);
            };
            this.Controls.Add(button);
            return button;
        }

        private void CarregarDadosCliente()
        {
            using (MySqlConnection conexao = ConsultarCliente.ligarBD.GetConnection())
            {
                conexao.Open();
                string query = "SELECT * FROM Cliente WHERE idCliente = @idCliente";
                MySqlCommand cmd = new MySqlCommand(query, conexao);
                cmd.Parameters.AddWithValue("@idCliente", idCliente);
                MySqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    txtNome.Text = reader["nome"].ToString();
                    txtMorada.Text = reader["morada"].ToString();
                    txtNIF.Text = reader["nif"].ToString();
                    txtTelefone.Text = reader["telefone"].ToString();
                    txtEmail.Text = reader["email"].ToString();
                }
            }
        }

        private void BtnSalvar_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos())
                return;

            using (MySqlConnection conexao = ConsultarCliente.ligarBD.GetConnection())
            {
                conexao.Open();
                string query = "UPDATE Cliente SET nome = @nome, morada = @morada, nif = @nif, telefone = @telefone, email = @Email WHERE idCliente = @idCliente";
                MySqlCommand cmd = new MySqlCommand(query, conexao);
                cmd.Parameters.AddWithValue("@nome", txtNome.Text);
                cmd.Parameters.AddWithValue("@morada", txtMorada.Text);
                cmd.Parameters.AddWithValue("@nif", txtNIF.Text);
                cmd.Parameters.AddWithValue("@telefone", txtTelefone.Text);
                cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                cmd.Parameters.AddWithValue("@idCliente", idCliente);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Dados do cliente atualizados com sucesso!");
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        private bool ValidarCampos()
        {
            if (txtNome.Text.Trim() == string.Empty)
            {
                MessageBox.Show("O campo Nome é obrigatório.", "Validação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (txtMorada.Text.Trim() == string.Empty)
            {
                MessageBox.Show("O campo Morada é obrigatório.", "Validação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (!Regex.IsMatch(txtNIF.Text, @"^\d{9}$"))
            {
                MessageBox.Show("O campo NIF deve ter exatamente 9 dígitos.", "Validação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (!Regex.IsMatch(txtTelefone.Text, @"^\d{9}$"))
            {
                MessageBox.Show("O campo Telefone deve ter exatamente 9 dígitos.", "Validação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (!Regex.IsMatch(txtEmail.Text, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                MessageBox.Show("O campo Email deve conter um endereço de email válido.", "Validação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }

        private void FormEditarCliente_Load(object sender, EventArgs e)
        {

        }
    }
}